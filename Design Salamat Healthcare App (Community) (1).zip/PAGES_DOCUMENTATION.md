# Salamat Healthcare App - Complete Pages Documentation

## Overview
This document provides a comprehensive explanation of all pages in the Salamat healthcare application, their structure, features, and functionality.

---

## 1. SPLASH SCREEN (`SplashScreen.tsx`)

### Purpose
Initial loading screen that appears when the app launches.

### Structure
```
├── Background
│   ├── Dark gradient (black to navy blue)
│   └── Decorative wave patterns (bottom, very low opacity)
├── Logo
│   ├── Blue heart icon with checkmark
│   └── SVG component (centered)
├── App Name
│   ├── "سلامات" (Arabic) / "Salamat" (English)
│   └── Large bold typography
└── Tagline
    ├── "منصة صحية متكاملة لرعايتك" (Arabic)
    └── "Integrated Healthcare Platform for Your Care" (English)
```

### Features
- Auto-navigates to login screen after 2.5 seconds
- Multi-language support (Arabic/English)
- RTL/LTR layout support
- No user interaction required

---

## 2. LOGIN SCREEN (`LoginScreen.tsx`)

### Purpose
Authentication page for users to access their health records.

### Structure
```
├── Logo Section
│   ├── Salamat logo (blue heart icon)
│   ├── App title
│   └── Subtitle
├── Login Form Card
│   ├── National ID Input
│   │   ├── 10-digit validation (regex: /^[0-9]{10}$/)
│   │   ├── Error message display
│   │   └── LTR direction (always)
│   └── Password Input
│       ├── Minimum 6 characters validation
│       ├── Password masking (••••••)
│       └── Error message display
├── Login Button
│   └── Triggers Sanad verification
├── Biometric Login Button
│   ├── Fingerprint icon
│   └── Opens biometric modal
├── Security Message Card
│   ├── Lock icon
│   └── Sanad system description
└── Verification Status
    ├── Loading: "Verifying credentials via Sanad..."
    └── Success: "Verification successful"
```

### Validation Rules
- **National ID**: Must be exactly 10 digits
- **Password**: Minimum 6 characters
- Shows error messages in real-time

### Features
- Two login methods:
  1. National ID + Password
  2. Biometric authentication (fingerprint)
- Sanad national verification system integration
- Visual feedback for verification process
- Multi-language support
- Dark/Light theme support
- RTL/LTR layout support

---

## 3. DASHBOARD / HOME SCREEN (`Dashboard.tsx`)

### Purpose
Main hub showing health overview and quick navigation.

### Structure
```
├── Header Bar
│   ├── App name ("Salamat")
│   ├── Notification bell (with red dot indicator)
│   ├── Welcome badge
│   └── Profile icon button
├── Alert Banner
│   ├── Bell icon
│   └── "New test results received" notification
├── Health Status Card
│   ├── Status title: "Overall Health Status"
│   ├── Status indicator: "Stable" with shield icon
│   ├── Last update timestamp
│   └── Reference number
├── Quick Action Grid (4 buttons)
│   ├── Medical Record → /records
│   ├── Charts → /charts
│   ├── Lab Tests → /lab-results
│   └── Notifications → /notifications (with indicator)
├── Latest Updates Section
│   ├── Section header with "View All" button
│   └── Update Cards
│       ├── Last lab test (FileText icon)
│       └── Last visit (Clock icon)
└── Health Content Section
    ├── Section header
    ├── Horizontal scrollable cards
    │   ├── Emoji icon
    │   ├── Content type badge
    │   ├── Verification checkmark
    │   ├── Article title
    │   ├── Description
    │   └── "Read More" button
    └── Verification footer
        └── "Content verified by certified medical authorities"
```

### Health Insights Articles (3 items)
1. **Cholesterol & Heart Health**
   - Icon: 🫀
   - Type: Medical article
   - Verified: Yes

2. **Healthy Diet for Cholesterol**
   - Icon: 🥗
   - Type: Dietary guide
   - Verified: Yes

3. **Exercise & Blood Sugar**
   - Icon: 🏃
   - Type: Medical study
   - Verified: Yes

### Features
- Real-time health status monitoring
- Quick access to all major features
- Educational health content
- Notification indicators
- Multi-language support
- Dark/Light theme support

---

## 4. PROFILE SCREEN (`ProfileScreen.tsx`)

### Purpose
Displays user personal information and connected healthcare entities.

### Structure
```
├── Header
│   ├── Back button → Dashboard
│   └── Page title: "Profile"
├── Profile Header Card (Gradient blue background)
│   ├── Profile Avatar
│   │   ├── User icon (circular)
│   │   └── White overlay background
│   ├── User Name
│   │   ├── Arabic: "محمد أحمد الخطيب"
│   │   └── English: "Mohammad Ahmad Al-Khatib"
│   └── Verification Badge
│       ├── Checkmark icon
│       └── "Verified via Sanad"
├── Personal Information Card
│   ├── National ID Number: 9851234567
│   ├── Date of Birth
│   │   ├── Arabic: "15 يناير 1985"
│   │   └── English: "January 15, 1985"
│   ├── Blood Type: O+
│   └── Phone Number: +962 79 123 4567 (LTR)
├── Identity Verification Card
│   ├── Checkmark icon (green)
│   ├── Title: "Verified by Sanad"
│   ├── Description
│   └── Green highlight background
└── Connected Entities Card
    ├── Section title
    └── Entity List (3 items)
        ├── Al-Bashir Hospital
        │   ├── Hospital icon
        │   └── Verified badge
        ├── Prince Hamza Hospital
        │   ├── Hospital icon
        │   └── Verified badge
        └── Biochemistry Labs
            ├── Lab icon (flask)
            └── Verified badge
```

### Personal Information Fields
1. **National ID Number**: 9851234567
2. **Date of Birth**: January 15, 1985 / 15 يناير 1985
3. **Blood Type**: O+
4. **Phone Number**: +962 79 123 4567

### Connected Entities (3)
1. **Al-Bashir Hospital** (Hospital) - Verified
2. **Prince Hamza Hospital** (Hospital) - Verified
3. **Biochemistry Medical Labs** (Laboratory) - Verified

### Features
- User identity display
- Sanad verification status
- Connected healthcare providers
- Jordanian hospital integration
- Multi-language support
- Dark/Light theme support
- RTL/LTR layout support

---

## 5. SETTINGS SCREEN (`SettingsScreen.tsx`)

### Purpose
Configuration page for app preferences and settings.

### Complete Structure
```
├── Header
│   ├── Back button → Dashboard
│   └── Page title: "Settings"
├── SECTION 1: Appearance
│   ├── Section icon: Moon
│   ├── Section title: "Appearance"
│   ├── Dark Mode Toggle
│   │   ├── Moon icon
│   │   ├── Label: "Dark Mode"
│   │   └── Switch button
│   │       ├── Off: Gray background
│   │       └── On: Blue background
│   └── Font Size Selection
│       ├── Type icon
│       ├── Label: "Font Size"
│       └── Three buttons
│           ├── Small (button)
│           ├── Medium (button - default)
│           └── Large (button)
├── SECTION 2: Language
│   ├── Section icon: Globe
│   ├── Section title: "Language"
│   └── Language Options
│       ├── Arabic Button
│       │   ├── Label: "العربية"
│       │   ├── Checkmark (when selected)
│       │   └── Blue border (when active)
│       └── English Button
│           ├── Label: "English"
│           ├── Checkmark (when selected)
│           └── Blue border (when active)
├── SECTION 3: Notifications
│   ├── Section icon: Bell
│   ├── Section title: "Notifications Settings"
│   ├── Enable Notifications Toggle
│   │   ├── Label: "Enable Notifications"
│   │   └── Switch button
│   └── Sub-options (shown when enabled)
│       ├── New Results Toggle
│       │   ├── Label: "New Test Results"
│       │   └── Switch button
│       └── Reminders Toggle
│           ├── Label: "Appointment Reminders"
│           └── Switch button
├── SECTION 4: Data Usage
│   ├── Section icon: Database
│   ├── Section title: "Data Usage"
│   └── Navigation Button
│       ├── Label: "View and Export Data"
│       ├── Arrow icon
│       └── Links to → /data-usage
└── SECTION 5: Privacy & Security
    ├── Section icon: Lock
    ├── Section title: "Privacy & Security"
    ├── Security Status Card (Green gradient)
    │   ├── Checkmark icon
    │   ├── Title: "Your data is protected"
    │   └── Description: "Secured with high-level encryption"
    └── Privacy Policy Button
        ├── Label: "More about Privacy Policy"
        └── Opens modal
```

### Settings Categories & Controls

#### 1. APPEARANCE SETTINGS
**Dark Mode Toggle**
- **Type**: Switch (on/off)
- **Function**: Changes entire app theme
  - Off: Light theme (white backgrounds, dark text)
  - On: Dark theme (dark backgrounds, light text)
- **Applies to**: All screens, cards, text, icons
- **Persistence**: Saved in Settings Context

**Font Size Selector**
- **Type**: Three-option button group
- **Options**:
  1. Small - Smaller text size
  2. Medium - Default text size
  3. Large - Larger text size (accessibility)
- **Function**: Adjusts text size across app
- **Active indicator**: Blue border + blue background
- **Persistence**: Saved in Settings Context

#### 2. LANGUAGE SETTINGS
**Language Selection**
- **Type**: Two-option buttons (mutually exclusive)
- **Options**:
  1. **Arabic (العربية)**
     - RTL (Right-to-Left) layout
     - Arabic text throughout
     - Icons flip direction
  2. **English**
     - LTR (Left-to-Right) layout
     - English text throughout
     - Standard icon direction
- **Active indicator**: 
  - Blue border
  - Blue background tint
  - Checkmark icon
- **Effect**: 
  - Changes all text immediately
  - Updates document direction
  - Flips layout orientation
- **Persistence**: Saved in Settings Context

#### 3. NOTIFICATIONS SETTINGS
**Master Notifications Toggle**
- **Type**: Switch (on/off)
- **Function**: Enables/disables all notifications
- **Effect**: Shows/hides sub-options

**Sub-options** (visible when master is ON):

1. **New Test Results**
   - **Type**: Switch (on/off)
   - **Function**: Receive alerts for new lab results
   - **Notification types**: 
     - Blood tests
     - Lab analysis
     - Medical reports

2. **Appointment Reminders**
   - **Type**: Switch (on/off)
   - **Function**: Receive appointment reminders
   - **Notification types**:
     - Doctor visits
     - Medication time
     - Follow-up appointments

**Behavior**:
- When master toggle is OFF, sub-options are hidden
- When master toggle is ON, sub-options appear
- Each sub-option works independently

#### 4. DATA USAGE SETTINGS
**View and Export Data Button**
- **Type**: Navigation button
- **Function**: Opens Data Usage screen
- **Destination**: `/data-usage`
- **Purpose**: 
  - View personal health data
  - Download complete records
  - Export in PDF/Word format
  - Check usage statistics

#### 5. PRIVACY & SECURITY SETTINGS
**Security Status Display**
- **Type**: Information card (read-only)
- **Display**:
  - Green gradient background
  - Checkmark icon
  - "Your data is protected"
  - "Secured with high-level encryption"
- **Purpose**: Reassures users about data security

**Privacy Policy Button**
- **Type**: Action button
- **Label**: "More about Privacy Policy"
- **Function**: Opens Privacy Policy Modal
- **Modal Contents**:
  - Full privacy policy text
  - Terms and conditions
  - Data usage information
  - Close button

### Features
- **Real-time Updates**: All settings apply immediately
- **Persistent Storage**: Settings saved to Context API
- **Visual Feedback**: Active states clearly indicated
- **Conditional Display**: Notification sub-options show/hide
- **Multi-language**: All labels translated
- **Theme Support**: Dark/Light mode for all elements
- **Layout Support**: RTL/LTR for all components

### Settings Persistence
All settings are stored in `SettingsContext` and persist during the session:
- Dark Mode state
- Font Size preference
- Language selection
- Notification preferences
- Sub-notification preferences

---

## 6. MEDICAL RECORDS SCREEN (`MedicalRecordsScreen.tsx`)

### Purpose
Shows complete history of medical visits and consultations.

### Structure
```
├── Header
│   ├── Back button → Dashboard
│   └── Page title: "Medical Records"
├── Overview Card
│   ├── Total visits count: 15
│   ├── Total records count: 23
│   └── Shield icon
└── Records List (6 items)
    ├── Record Card (for each)
    │   ├── Icon (category-based)
    │   ├── Visit Type
    │   ├── Date (AR/EN)
    │   ├── Doctor name
    │   ├── Hospital name
    │   ├── Verified badge
    │   └── Arrow icon → Visit Details
```

### Sample Records (6 entries)
1. **Cardiology Consultation**
   - Date: April 15, 2026 / 15 أبريل 2026
   - Doctor: Dr. Ahmad Hamoud
   - Location: Al-Bashir Hospital
   - Status: Verified

2. **General Checkup**
   - Date: April 10, 2026 / 10 أبريل 2026
   - Doctor: Dr. Sarah Khatib
   - Location: Prince Hamza Hospital
   - Status: Verified

3. **Dermatology Consultation**
   - Date: March 28, 2026 / 28 مارس 2026
   - Doctor: Dr. Khaled Nusour
   - Location: Al-Bashir Hospital
   - Status: Verified

4. **Ophthalmology Exam**
   - Date: March 15, 2026 / 15 مارس 2026
   - Doctor: Dr. Layla Omari
   - Location: Prince Hamza Hospital
   - Status: Verified

5. **Cardiology Follow-up**
   - Date: February 20, 2026 / 20 فبراير 2026
   - Doctor: Dr. Ahmad Hamoud
   - Location: Al-Bashir Hospital
   - Status: Verified

6. **Annual Physical**
   - Date: January 10, 2026 / 10 يناير 2026
   - Doctor: Dr. Sarah Khatib
   - Location: Prince Hamza Hospital
   - Status: Verified

### Features
- Complete visit history
- Chronological ordering (newest first)
- Visit type categorization
- Doctor information
- Hospital location
- Verification status
- Tap to view details
- Multi-language dates
- Dark/Light theme support

---

## 7. VISIT DETAILS SCREEN (`VisitDetailsScreen.tsx`)

### Purpose
Detailed information about a specific medical visit.

### Structure
```
├── Header
│   ├── Back button → Medical Records
│   └── Page title: "Visit Details"
├── Visit Information Card
│   ├── Date
│   │   ├── Calendar icon
│   │   └── Visit date (AR/EN)
│   └── Treating Doctor
│       ├── User icon
│       ├── Doctor name
│       └── Specialty
├── Diagnosis Card
│   ├── FileText icon
│   ├── Section title: "Diagnosis"
│   └── Diagnosis description
├── Prescribed Medications Card
│   ├── Pill icon
│   ├── Section title: "Prescribed Medications"
│   └── Medication List
│       ├── Medication 1
│       │   ├── Name: Aspirin 100mg
│       │   └── Dosage: Once daily after breakfast
│       └── Medication 2
│           ├── Name: Vitamin D 50000 IU
│           └── Dosage: Once weekly
└── Additional Notes Card
    ├── Section title: "Additional Notes"
    └── Doctor's recommendations
```

### Example Visit Data
**Visit Date**: April 15, 2026 / 15 أبريل 2026

**Doctor**: Dr. Ahmad Hamoud
- Specialty: Cardiology Consultant

**Diagnosis**: Routine cardiac examination. Heart functioning normally. Blood pressure within normal range. No signs of any health issues.

**Medications**:
1. Aspirin 100mg - Once daily after breakfast
2. Vitamin D 50000 IU - Once weekly

**Additional Notes**: Regular exercise recommended, walking 30 minutes daily. Reduce salt intake. Follow-up in 6 months.

### Features
- Complete visit documentation
- Doctor information
- Diagnosis details
- Medication instructions
- Medical recommendations
- Multi-language support
- Dark/Light theme support

---

## 8. LAB RESULTS SCREEN (`LabResultsScreen.tsx`)

### Purpose
List of all laboratory test results.

### Structure
```
├── Header
│   ├── Back button → Dashboard
│   └── Page title: "Lab Results"
└── Results List (6 items)
    ├── Result Card (for each)
    │   ├── Test Name (AR/EN)
    │   ├── Date (AR/EN)
    │   ├── Status Icon
    │   │   ├── Normal: Green checkmark
    │   │   ├── Warning: Yellow warning triangle
    │   │   └── Critical: Red warning triangle
    │   ├── Status Label
    │   ├── Status Indicator Dot
    │   └── Arrow icon → Analysis Details
```

### Test Results (6 entries)

1. **Complete Blood Count**
   - Date: April 20, 2026 / 20 أبريل 2026
   - Status: Normal (Green)

2. **HbA1c Test**
   - Date: April 18, 2026 / 18 أبريل 2026
   - Status: Normal (Green)

3. **Cholesterol Test**
   - Date: April 18, 2026 / 18 أبريل 2026
   - Status: Warning (Yellow)

4. **Kidney Function Test**
   - Date: April 10, 2026 / 10 أبريل 2026
   - Status: Normal (Green)

5. **Liver Function Test**
   - Date: April 10, 2026 / 10 أبريل 2026
   - Status: Normal (Green)

6. **Vitamin D Test**
   - Date: April 5, 2026 / 5 أبريل 2026
   - Status: Warning (Yellow)

### Status Colors
- **Normal**: Green (#27AE60) - All values in normal range
- **Warning**: Yellow (#F2C94C) - Slight elevation/decrease
- **Critical**: Red (#EB5757) - Significant deviation

### Features
- All lab results in one place
- Visual status indicators
- Color-coded results
- Tap to view detailed analysis
- Chronological ordering
- Multi-language support
- Dark/Light theme support

---

## 9. ANALYSIS DETAILS SCREEN (`AnalysisDetailsScreen.tsx`)

### Purpose
Comprehensive view of a specific lab test with detailed results and trends.

### Structure
```
├── Header
│   ├── Back button → Lab Results
│   ├── Page title: "Analysis Details"
│   └── Share button → Share Screen
├── PDF Report Card
│   ├── Section title: "PDF Report"
│   ├── Control Buttons
│   │   ├── Zoom In
│   │   ├── Zoom Out
│   │   └── Show/Hide (Eye icon)
│   └── PDF Preview Area
│       └── FileText icon + "PDF Preview" text
├── Quick Summary Section
│   ├── Section title: "Quick Summary"
│   └── Summary Cards (2)
│       ├── Glucose Card (Green)
│       │   ├── Status: Normal
│       │   ├── Value: 94
│       │   └── Checkmark icon
│       └── Cholesterol Card (Yellow)
│           ├── Status: Warning
│           ├── Value: 210
│           └── Warning triangle icon
├── Graph Section
│   ├── Section title: "Graph"
│   ├── Trending Up icon
│   ├── Blood Sugar Chart
│   │   ├── Chart title
│   │   ├── Line chart
│   │   │   ├── X-axis: Months (dynamic language)
│   │   │   ├── Y-axis: Values
│   │   │   ├── Grid lines
│   │   │   ├── Tooltip (dark mode support)
│   │   │   └── Green line
│   │   └── Data: Jan(95), Feb(92), Mar(98), Apr(94)
│   └── Cholesterol Chart
│       ├── Chart title
│       ├── Line chart
│       │   ├── X-axis: Months (dynamic language)
│       │   ├── Y-axis: Values
│       │   ├── Grid lines
│       │   ├── Tooltip (dark mode support)
│       │   └── Yellow line
│       └── Data: Jan(180), Feb(185), Mar(195), Apr(210)
├── What Does It Mean Section
│   ├── Section title: "What Does It Mean?"
│   ├── Blue gradient background
│   └── Explanations List
│       ├── Glucose Explanation
│       │   ├── Checkmark icon (green)
│       │   └── "Your glucose level is normal and indicates good health"
│       ├── Cholesterol Explanation
│       │   ├── Warning triangle icon (yellow)
│       │   └── "Slight increase in cholesterol, advised to reduce dietary fats"
│       └── HDL Explanation
│           ├── Checkmark icon (green)
│           └── "Good cholesterol is within normal range"
└── Detailed Analysis Section
    ├── Section title: "Detailed Analysis"
    └── Test Results Table
        ├── Row: Fasting Blood Glucose
        │   ├── Status icon
        │   ├── Test name
        │   ├── Value: 94 mg/dL
        │   ├── Normal range: 70-100
        │   └── Status: Normal
        ├── Row: HbA1c
        │   ├── Value: 5.4%
        │   ├── Normal range: 4.0-5.6
        │   └── Status: Normal
        ├── Row: Total Cholesterol
        │   ├── Value: 210 mg/dL
        │   ├── Normal range: < 200
        │   └── Status: Warning
        ├── Row: HDL Cholesterol
        │   ├── Value: 52 mg/dL
        │   ├── Normal range: > 40
        │   └── Status: Normal
        ├── Row: LDL Cholesterol
        │   ├── Value: 135 mg/dL
        │   ├── Normal range: < 100
        │   └── Status: Warning
        └── Row: Triglycerides
            ├── Value: 115 mg/dL
            ├── Normal range: < 150
            └── Status: Normal
```

### Test Parameters (6)
1. **Fasting Blood Glucose**: 94 mg/dL (Normal: 70-100)
2. **HbA1c**: 5.4% (Normal: 4.0-5.6)
3. **Total Cholesterol**: 210 mg/dL (Normal: < 200) ⚠️
4. **HDL Cholesterol**: 52 mg/dL (Normal: > 40)
5. **LDL Cholesterol**: 135 mg/dL (Normal: < 100) ⚠️
6. **Triglycerides**: 115 mg/dL (Normal: < 150)

### Chart Features
- **Dynamic Language**: Month names change with language
- **Dark Mode Support**: Grid, axes, tooltip colors adapt
- **Interactive Tooltips**: Hover to see values
- **Trend Visualization**: 4-month history
- **Color Coding**: Green for normal, yellow for warning

### Features
- PDF report preview
- Visual summary cards
- Interactive trend charts
- Plain language explanations
- Detailed test results
- Normal range comparisons
- Share functionality
- Multi-language support
- Dark/Light theme support
- RTL/LTR layout support

---

## 10. CHARTS SCREEN (`ChartsScreen.tsx`)

### Purpose
Visual representation of health metrics over time.

### Structure
```
├── Header
│   ├── Back button → Dashboard
│   └── Page title: "Charts"
└── Charts List (3 charts)
    ├── Blood Sugar Chart Card
    │   ├── Chart title
    │   ├── TrendingUp icon (green)
    │   ├── Current value: 94 mg/dL
    │   ├── Status: "Within normal range"
    │   └── Line Chart
    │       ├── Data: 4 months
    │       ├── Green line
    │       └── Interactive tooltip
    ├── Blood Pressure Chart Card
    │   ├── Chart title
    │   ├── TrendingUp icon (blue)
    │   ├── Current value: 119/79 mmHg
    │   ├── Status: "Normal pressure"
    │   └── Line Chart
    │       ├── Data: 4 months
    │       ├── Blue line (systolic)
    │       ├── Purple line (diastolic)
    │       └── Interactive tooltip
    └── Cholesterol Chart Card
        ├── Chart title
        ├── TrendingUp icon (yellow)
        ├── Current value: 210 mg/dL
        ├── Status: "Slight increase"
        └── Line Chart
            ├── Data: 4 months
            ├── Yellow line
            └── Interactive tooltip
```

### Chart Data

**1. Blood Sugar (Glucose)**
- January: 95 mg/dL / يناير: 95
- February: 92 mg/dL / فبراير: 92
- March: 98 mg/dL / مارس: 98
- April: 94 mg/dL / أبريل: 94
- Color: Green (#27AE60)
- Status: Within normal range

**2. Blood Pressure**
- January: 120/80 mmHg / يناير: 120/80
- February: 118/78 mmHg / فبراير: 118/78
- March: 122/82 mmHg / مارس: 122/82
- April: 119/79 mmHg / أبريل: 119/79
- Colors: Blue (#2F80ED) + Purple (#9B51E0)
- Status: Normal pressure

**3. Cholesterol**
- January: 180 mg/dL / يناير: 180
- February: 185 mg/dL / فبراير: 185
- March: 195 mg/dL / مارس: 195
- April: 210 mg/dL / أبريل: 210
- Color: Yellow (#F2C94C)
- Status: Slight increase

### Chart Features
- **Dynamic Month Labels**: Arabic/English based on language
- **Dark Mode Support**: Grid, axes, tooltips adapt to theme
- **Interactive Tooltips**: Show exact values on hover
- **Color Coding**: Health status indication
- **Trend Lines**: Smooth curves showing patterns
- **Current Values**: Large display at top
- **Status Text**: Plain language interpretation

### Features
- Three vital health metrics
- Historical trend analysis
- Visual health monitoring
- Color-coded health status
- Interactive data exploration
- Multi-language support
- Dark/Light theme support

---

## 11. SHARE & DOWNLOAD SCREEN (`ShareScreen.tsx`)

### Purpose
Share medical records securely or download them for offline use.

### Structure
```
├── Header
│   ├── Back button
│   └── Page title: "Share & Download"
├── Security Banner
│   ├── Lock icon
│   ├── Title: "Secure Sharing"
│   └── Description: Encryption and 24-hour expiry notice
├── Generated Link Display (if created)
│   ├── Checkmark icon
│   ├── Title: "Secure Link"
│   ├── Validity: "Valid for 24 hours"
│   ├── Link URL (copyable)
│   └── Copy button
├── Share Methods Section
│   ├── Section title: "Choose Share Method"
│   └── Share Options (4 buttons)
│       ├── Share with Doctor
│       │   ├── Share2 icon (blue)
│       │   ├── Title
│       │   └── Description
│       ├── Create Secure Link
│       │   ├── Link2 icon (green)
│       │   ├── Title
│       │   └── Description
│       ├── Send via Email
│       │   ├── Mail icon (yellow)
│       │   ├── Title
│       │   └── Description
│       └── Share via WhatsApp
│           ├── MessageCircle icon (purple)
│           ├── Title
│           └── Description
├── Download Section
│   ├── Section title: "Download Files"
│   └── Download Button
│       ├── Download icon (red)
│       ├── Title: "Download as PDF"
│       └── Description: "Save copy to device"
└── Active Shares Section
    ├── Section title: "Active Shares"
    └── Active Share Card
        ├── Doctor name: Dr. Ahmad Hamoud
        ├── Expiry: "Expires in 18 hours"
        ├── Checkmark icon (green)
        ├── Lock icon
        └── "Password protected" label
```

### Functional Buttons

#### 1. SHARE WITH DOCTOR
- **Icon**: Share2 (blue)
- **Function**: Share directly with treating physician
- **Process**:
  1. Shows loading toast: "Processing..."
  2. Simulates network request (1.5s)
  3. Success: "Shared successfully" toast
  4. Error: "No internet connection" or "Sharing failed"

#### 2. CREATE SECURE LINK
- **Icon**: Link2 (green)
- **Function**: Generate shareable encrypted link
- **Process**:
  1. Shows loading toast: "Processing..."
  2. Generates unique URL (salamat.jo/share/[id])
  3. Automatically copies link to clipboard
  4. Displays link in green card with copy button
  5. Shows success toast: "Link copied to clipboard"
  6. Link expires in 24 hours
- **Generated Link Example**: `https://salamat.jo/share/a7k9x2p`

#### 3. SEND VIA EMAIL
- **Icon**: Mail (yellow)
- **Function**: Send records to email address
- **Process**:
  1. Shows loading toast: "Processing..."
  2. Simulates email sending (1.5s)
  3. Success: "Email sent" toast
  4. Error: "No internet connection" or "Sharing failed"

#### 4. SHARE VIA WHATSAPP
- **Icon**: MessageCircle (purple)
- **Function**: Share via WhatsApp application
- **Process**:
  1. Shows loading toast: "Processing..."
  2. Opens WhatsApp with pre-filled message
  3. Opens in new window/tab
  4. Success toast: "Shared successfully"
  5. Error: "No internet connection" or "Sharing failed"

#### 5. DOWNLOAD AS PDF
- **Icon**: Download (red)
- **Function**: Download complete health record
- **Process**:
  1. Shows loading toast: "Processing..."
  2. Generates PDF file (1.5s)
  3. Triggers browser download
  4. File name: `salamat-health-record.pdf`
  5. Success toast: "Downloaded successfully"
  6. Error: "Download failed" or "No internet connection"

### Toast Notifications
All actions provide visual feedback:

**Loading State**:
- Blue spinner icon
- Message: "Processing..." / "جاري المعالجة..."
- Stays until action completes

**Success States**:
- Green checkmark icon
- Messages:
  - "Shared successfully" / "تم المشاركة بنجاح"
  - "Link copied to clipboard" / "تم نسخ الرابط إلى الحافظة"
  - "Email sent" / "تم إرسال البريد الإلكتروني"
  - "Downloaded successfully" / "تم التحميل بنجاح"
- Auto-dismiss after 3 seconds

**Error States**:
- Red X icon
- Messages:
  - "No internet connection" / "لا يوجد اتصال بالإنترنت"
  - "Sharing failed" / "فشلت عملية المشاركة"
  - "Download failed" / "فشل التحميل"
- Auto-dismiss after 3 seconds

### Error Handling
- **Network Simulation**: 90% success rate (for testing)
- **No Internet**: Detects and shows specific error
- **Try-Catch Blocks**: All operations wrapped in error handling
- **Clipboard API**: Fallback handling if clipboard access denied
- **User Feedback**: Every action has loading → success/error flow

### Features
- **Security**: 
  - Encrypted links
  - 24-hour expiration
  - Password protection
- **Functionality**: All buttons fully operational
- **Feedback**: Toast notifications for all actions
- **Error Handling**: Network errors, permission issues
- **Copy to Clipboard**: One-click link copying
- **External Sharing**: WhatsApp integration
- **File Download**: PDF generation and download
- **Active Tracking**: Shows current shares
- **Multi-language**: All text translated
- **Theme Support**: Dark/Light mode
- **Layout Support**: RTL/LTR

---

## 12. NOTIFICATIONS SCREEN (`NotificationsScreen.tsx`)

### Purpose
Display all health-related notifications and alerts.

### Structure
```
├── Header
│   ├── Back button → Dashboard
│   └── Page title: "Notifications"
└── Notifications List (6 items)
    ├── Notification Card (for each)
    │   ├── Icon (category-based)
    │   │   ├── FileText (documents)
    │   │   ├── Calendar (appointments)
    │   │   ├── AlertTriangle (warnings)
    │   │   ├── Clock (visits)
    │   │   └── Pill (medications)
    │   ├── Title
    │   ├── Description
    │   └── Timestamp (relative)
```

### Notifications (6 entries)

1. **New Result Added**
   - Icon: FileText (blue)
   - Title: "New result added"
   - Message: "Complete Blood Test available now"
   - Time: 2 hours ago / منذ ساعتين

2. **Doctor Appointment Reminder**
   - Icon: Calendar (green)
   - Title: "Doctor appointment reminder"
   - Message: "Next follow-up appointment on Sunday"
   - Time: Yesterday / أمس

3. **Cholesterol Results**
   - Icon: AlertTriangle (yellow)
   - Title: "Cholesterol test results"
   - Message: "Slight increase, review details"
   - Time: 2 days ago / منذ يومين

4. **New Visit Recorded**
   - Icon: Clock (purple)
   - Title: "New visit recorded"
   - Message: "Visit with Dr. Ahmad - April 15"
   - Time: 3 days ago / منذ 3 أيام

5. **Complete Blood Test**
   - Icon: FileText (blue)
   - Title: "Complete blood test"
   - Message: "All results within normal range"
   - Time: 3 days ago / منذ 3 أيام

6. **Medication Time**
   - Icon: Pill (red)
   - Title: "Medication time"
   - Message: "Aspirin 100mg - After breakfast"
   - Time: 5 hours ago / منذ 5 ساعات

### Notification Types
- **New Results**: Lab test results available
- **Appointments**: Upcoming doctor visits
- **Warnings**: Health alerts requiring attention
- **Visit Records**: New medical visit added
- **Medications**: Medication reminders

### Features
- Real-time notifications
- Category icons
- Relative timestamps
- Chronological ordering
- Multi-language support
- Dark/Light theme support
- RTL/LTR layout support

---

## 13. TIMELINE SCREEN (`TimelineScreen.tsx`)

### Purpose
Chronological view of all health events.

### Structure
```
├── Header
│   ├── Back button → Medical Records
│   └── Page title: "Timeline"
└── Timeline List
    ├── Timeline Item (for each event)
    │   ├── Date Badge
    │   ├── Vertical Line
    │   ├── Event Card
    │   │   ├── Icon
    │   │   ├── Event title
    │   │   ├── Event description
    │   │   └── Location/Doctor info
    │   └── Connection to next item
```

### Features
- Chronological health history
- Visual timeline representation
- Event categorization
- Date grouping
- Multi-language support
- Dark/Light theme support

---

## 14. E-SERVICES SCREEN (`EServicesScreen.tsx`)

### Purpose
Access to electronic healthcare services.

### Structure
```
├── Header
│   ├── Back button
│   └── Page title: "E-Services"
├── Available Services Section
│   ├── Section title
│   └── Service Cards (3)
│       ├── Request Medical Report
│       │   ├── FileText icon
│       │   ├── Title
│       │   └── Description
│       ├── Share Results
│       │   ├── Share2 icon
│       │   ├── Title
│       │   └── Description
│       └── Download Records
│           ├── Download icon
│           ├── Title
│           └── Description
└── Previous Requests Section
    ├── Section title
    └── Request Cards (3)
        ├── Complete Medical Report
        │   ├── Status: Approved
        │   └── Date
        ├── Share Lab Results
        │   ├── Status: Completed
        │   └── Date
        └── Insurance Report
            ├── Status: Processing
            └── Date
```

### Available Services (3)
1. **Request Medical Report**
   - Get comprehensive report of all records
   
2. **Share Results**
   - Share medical results with doctor

3. **Download Records**
   - Download copy of medical records

### Features
- Self-service healthcare
- Request tracking
- Status monitoring
- Previous requests history
- Multi-language support
- Dark/Light theme support

---

## 15. DATA USAGE SCREEN (`DataUsageScreen.tsx`)

### Purpose
View and export personal health data.

### Structure
```
├── Header
│   ├── Back button → Settings
│   └── Page title: "Data Usage"
├── Complete Health Record Card
│   ├── Title
│   ├── Description
│   └── Download Buttons (2)
│       ├── Download PDF
│       └── Download Word
├── Personal Information Card
│   ├── Full Name
│   ├── National ID
│   ├── Email
│   └── Address
└── Usage Statistics Card
    ├── Visits: 15
    ├── Lab Tests: 23
    └── Health Information items: 45
```

### Personal Information
- **Full Name**: Mohammad Ahmad Al-Khatib / محمد أحمد الخطيب
- **National ID**: 9851234567
- **Email**: (user email)
- **Address**: Amman, Jordan / عمان، الأردن

### Usage Statistics
- **Visits**: 15 medical visits
- **Lab Tests**: 23 completed tests
- **Health Info**: 45 information items

### Features
- Complete data access
- Export functionality (PDF/Word)
- Personal information display
- Usage statistics
- GDPR compliance
- Multi-language support
- Dark/Light theme support

---

## 16. IDENTITY VERIFIED SCREEN (`IdentityVerifiedScreen.tsx`)

### Purpose
Confirmation screen after successful Sanad verification.

### Structure
```
├── Success Animation
├── Checkmark Icon (large, green)
├── Success Message
│   ├── "Identity Verified Successfully"
│   └── Via Sanad national system
└── Continue Button
    └── Navigate to Dashboard
```

### Features
- Visual confirmation
- Sanad integration confirmation
- Auto-navigation option
- Multi-language support
- Dark/Light theme support

---

## BOTTOM NAVIGATION BAR

Present on all main screens (Dashboard, Records, Charts, Profile, Settings).

### Structure
```
└── Navigation Bar (5 tabs)
    ├── Home Tab
    │   ├── Home icon
    │   └── Label: "Home"
    ├── Records Tab
    │   ├── FileText icon
    │   └── Label: "Records"
    ├── Charts Tab
    │   ├── TrendingUp icon
    │   └── Label: "Charts"
    ├── Profile Tab
    │   ├── User icon
    │   └── Label: "Profile"
    └── Settings Tab
        ├── Settings icon
        └── Label: "Settings"
```

### Features
- Fixed bottom position
- Active tab highlighting (blue)
- Icon + text labels
- Tap navigation
- Multi-language labels
- Dark/Light theme support

---

## COMMON FEATURES ACROSS ALL PAGES

### Multi-Language Support
- **Arabic (AR)**: RTL layout, Arabic text
- **English (EN)**: LTR layout, English text
- Translation system: `t()` function from SettingsContext
- Dynamic content based on `isRTL` boolean

### Theme Support
- **Light Mode**: White backgrounds, dark text
- **Dark Mode**: Dark backgrounds, light text
- All colors adapt to theme
- Consistent across all pages

### Navigation
- Back buttons on all sub-pages
- Bottom navigation on main pages
- Breadcrumb trails
- Deep linking support

### Accessibility
- Font size options (Small/Medium/Large)
- High contrast colors
- Clear visual hierarchy
- Touch-friendly buttons

### Visual Design
- **Primary Color**: #2F80ED (Blue)
- **Success Color**: #27AE60 (Green)
- **Warning Color**: #F2C94C (Yellow)
- **Danger Color**: #EB5757 (Red)
- Rounded corners (2xl = 16px)
- Consistent spacing (4px grid)
- Shadow elevations

---

## TECHNICAL IMPLEMENTATION

### State Management
- **SettingsContext**: Global settings (theme, language, font, notifications)
- **React Router**: Client-side routing
- **Local State**: Component-specific data (useState)

### Styling
- **Tailwind CSS v4**: Utility-first CSS framework
- **Custom Theme**: `/src/styles/theme.css`
- **Responsive**: Mobile-first design

### Components
- **Reusable**: Toast, Modal, Card components
- **Icon Library**: Lucide React
- **Charts**: Recharts library

### Data Sources
- **Mock Data**: Currently using sample data
- **API Ready**: Structure ready for backend integration
- **Jordanian Context**: Hospitals, phone numbers, doctor names

---

## SUMMARY OF ALL PAGES

1. **Splash Screen**: App intro with logo
2. **Login Screen**: Authentication (National ID + Password / Biometric)
3. **Dashboard**: Health overview and quick actions
4. **Profile Screen**: Personal information and connected entities
5. **Settings Screen**: App preferences (appearance, language, notifications, privacy)
6. **Medical Records**: Visit history list
7. **Visit Details**: Detailed visit information
8. **Lab Results**: Test results list
9. **Analysis Details**: Detailed test analysis with charts
10. **Charts Screen**: Health metrics visualization
11. **Share & Download**: Functional sharing and download options
12. **Notifications**: Health alerts and reminders
13. **Timeline**: Chronological health events
14. **E-Services**: Electronic services and requests
15. **Data Usage**: Personal data viewing and export
16. **Identity Verified**: Verification confirmation

**Total Pages**: 16 screens
**Languages**: 2 (Arabic, English)
**Themes**: 2 (Light, Dark)
**Navigation**: Bottom bar + Back buttons

---

*End of Documentation*
