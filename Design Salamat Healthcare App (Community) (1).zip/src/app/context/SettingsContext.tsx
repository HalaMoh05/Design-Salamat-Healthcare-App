import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { translations, Language, TranslationKey } from '../translations/translations';

interface SettingsContextType {
  darkMode: boolean;
  setDarkMode: (value: boolean) => void;
  fontSize: 'small' | 'medium' | 'large';
  setFontSize: (value: 'small' | 'medium' | 'large') => void;
  language: Language;
  setLanguage: (value: Language) => void;
  notifications: boolean;
  setNotifications: (value: boolean) => void;
  newResults: boolean;
  setNewResults: (value: boolean) => void;
  reminders: boolean;
  setReminders: (value: boolean) => void;
  t: (key: TranslationKey) => string;
  isRTL: boolean;
}

const SettingsContext = createContext<SettingsContextType | undefined>(undefined);

export function SettingsProvider({ children }: { children: ReactNode }) {
  const [darkMode, setDarkModeState] = useState(false);
  const [fontSize, setFontSizeState] = useState<'small' | 'medium' | 'large'>('medium');
  const [language, setLanguageState] = useState<Language>('ar');
  const [notifications, setNotifications] = useState(true);
  const [newResults, setNewResults] = useState(true);
  const [reminders, setReminders] = useState(true);

  const setDarkMode = (value: boolean) => {
    setDarkModeState(value);
    if (value) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  };

  const setFontSize = (value: 'small' | 'medium' | 'large') => {
    setFontSizeState(value);
    const root = document.documentElement;
    switch (value) {
      case 'small':
        root.style.setProperty('--font-size', '14px');
        break;
      case 'medium':
        root.style.setProperty('--font-size', '16px');
        break;
      case 'large':
        root.style.setProperty('--font-size', '18px');
        break;
    }
  };

  const setLanguage = (value: Language) => {
    setLanguageState(value);
    document.documentElement.dir = value === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = value;
  };

  const t = (key: TranslationKey): string => {
    return translations[language][key] || key;
  };

  const isRTL = language === 'ar';

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    }
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = language;
  }, []);

  return (
    <SettingsContext.Provider
      value={{
        darkMode,
        setDarkMode,
        fontSize,
        setFontSize,
        language,
        setLanguage,
        notifications,
        setNotifications,
        newResults,
        setNewResults,
        reminders,
        setReminders,
        t,
        isRTL,
      }}
    >
      {children}
    </SettingsContext.Provider>
  );
}

export function useSettings() {
  const context = useContext(SettingsContext);
  if (context === undefined) {
    throw new Error('useSettings must be used within a SettingsProvider');
  }
  return context;
}
