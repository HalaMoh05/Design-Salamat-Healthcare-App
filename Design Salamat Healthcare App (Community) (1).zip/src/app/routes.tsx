import { createBrowserRouter } from 'react-router';
import { SplashScreen } from './components/SplashScreen';
import { LoginScreen } from './components/LoginScreen';
import { IdentityVerifiedScreen } from './components/IdentityVerifiedScreen';
import { Dashboard } from './components/Dashboard';
import { MedicalRecordsScreen } from './components/MedicalRecordsScreen';
import { VisitDetailsScreen } from './components/VisitDetailsScreen';
import { LabResultsScreen } from './components/LabResultsScreen';
import { AnalysisDetailsScreen } from './components/AnalysisDetailsScreen';
import { ChartsScreen } from './components/ChartsScreen';
import { TimelineScreen } from './components/TimelineScreen';
import { NotificationsScreen } from './components/NotificationsScreen';
import { EServicesScreen } from './components/EServicesScreen';
import { ShareScreen } from './components/ShareScreen';
import { ProfileScreen } from './components/ProfileScreen';
import { SettingsScreen } from './components/SettingsScreen';
import { DataUsageScreen } from './components/DataUsageScreen';
import { BottomNavigation } from './components/BottomNavigation';

function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-[#F5F7FA]">
      {children}
      <BottomNavigation />
    </div>
  );
}

export const router = createBrowserRouter([
  {
    path: '/',
    element: <SplashScreen />,
  },
  {
    path: '/login',
    element: <LoginScreen />,
  },
  {
    path: '/verified',
    element: <IdentityVerifiedScreen />,
  },
  {
    path: '/dashboard',
    element: <Layout><Dashboard /></Layout>,
  },
  {
    path: '/records',
    element: <Layout><MedicalRecordsScreen /></Layout>,
  },
  {
    path: '/visit/:id',
    element: <Layout><VisitDetailsScreen /></Layout>,
  },
  {
    path: '/lab-results',
    element: <Layout><LabResultsScreen /></Layout>,
  },
  {
    path: '/analysis/:id',
    element: <Layout><AnalysisDetailsScreen /></Layout>,
  },
  {
    path: '/charts',
    element: <Layout><ChartsScreen /></Layout>,
  },
  {
    path: '/timeline',
    element: <Layout><TimelineScreen /></Layout>,
  },
  {
    path: '/notifications',
    element: <Layout><NotificationsScreen /></Layout>,
  },
  {
    path: '/e-services',
    element: <Layout><EServicesScreen /></Layout>,
  },
  {
    path: '/share',
    element: <Layout><ShareScreen /></Layout>,
  },
  {
    path: '/profile',
    element: <Layout><ProfileScreen /></Layout>,
  },
  {
    path: '/settings',
    element: <Layout><SettingsScreen /></Layout>,
  },
  {
    path: '/data-usage',
    element: <Layout><DataUsageScreen /></Layout>,
  },
]);
