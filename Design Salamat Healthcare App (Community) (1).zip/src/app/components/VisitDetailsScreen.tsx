import { useNavigate, useParams } from 'react-router';
import { ArrowRight, Calendar, User, FileText, Pill } from 'lucide-react';
import { useSettings } from '../context/SettingsContext';

export function VisitDetailsScreen() {
  const navigate = useNavigate();
  const { id } = useParams();
  const { t, isRTL, darkMode } = useSettings();

  return (
    <div className={`pb-20 ${darkMode ? 'bg-[#121212]' : 'bg-[#F5F7FA]'}`} dir={isRTL ? 'rtl' : 'ltr'}>
      <div className={`${darkMode ? 'bg-[#1a1a1a] border-gray-800' : 'bg-white border-[#E5E7EB]'} px-6 py-4 flex items-center gap-3 border-b sticky top-0 z-10`}>
        <button onClick={() => navigate('/records')} className="p-2">
          <ArrowRight className={`w-6 h-6 ${darkMode ? 'text-white' : 'text-[#1a1a1a]'} ${isRTL ? '' : 'rotate-180'}`} />
        </button>
        <h2 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-xl flex-1`}>{t('visitDetails')}</h2>
      </div>

      <div className="px-6 py-6">
        <div className={`${darkMode ? 'bg-[#1a1a1a]' : 'bg-white'} rounded-2xl p-6 shadow-sm mb-4`}>
          <h3 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-lg mb-4`}>{t('visitInfo')}</h3>
          <div className="space-y-4">
            <div className="flex items-start gap-3">
              <Calendar className="w-5 h-5 text-[#2F80ED] mt-0.5" />
              <div>
                <p className={`${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} text-sm mb-1`}>{t('date')}</p>
                <p className={darkMode ? 'text-white' : 'text-[#1a1a1a]'}>
                  {isRTL ? '15 أبريل 2026' : 'April 15, 2026'}
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <User className="w-5 h-5 text-[#2F80ED] mt-0.5" />
              <div>
                <p className={`${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} text-sm mb-1`}>{t('treatingDoctor')}</p>
                <p className={darkMode ? 'text-white' : 'text-[#1a1a1a]'}>{t('drAhmadHamoud')}</p>
                <p className={`${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} text-sm`}>{t('cardiologyConsultant')}</p>
              </div>
            </div>
          </div>
        </div>

        <div className={`${darkMode ? 'bg-[#1a1a1a]' : 'bg-white'} rounded-2xl p-6 shadow-sm mb-4`}>
          <div className="flex items-center gap-2 mb-3">
            <FileText className="w-5 h-5 text-[#2F80ED]" />
            <h3 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-lg`}>{t('diagnosis')}</h3>
          </div>
          <p className={`${darkMode ? 'text-gray-300' : 'text-[#1a1a1a]'} leading-relaxed`}>
            {t('routineCardiacCheck')}
          </p>
        </div>

        <div className={`${darkMode ? 'bg-[#1a1a1a]' : 'bg-white'} rounded-2xl p-6 shadow-sm mb-4`}>
          <div className="flex items-center gap-2 mb-3">
            <Pill className="w-5 h-5 text-[#2F80ED]" />
            <h3 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-lg`}>{t('prescribedMedications')}</h3>
          </div>
          <div className="space-y-3">
            <div className={`p-3 ${darkMode ? 'bg-gray-800' : 'bg-[#F5F7FA]'} rounded-xl`}>
              <p className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} mb-1`}>{t('aspirin100mg')}</p>
              <p className={`${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} text-sm`}>{t('onceDaily')}</p>
            </div>
            <div className={`p-3 ${darkMode ? 'bg-gray-800' : 'bg-[#F5F7FA]'} rounded-xl`}>
              <p className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} mb-1`}>{t('vitaminD50000')}</p>
              <p className={`${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} text-sm`}>{t('onceWeekly')}</p>
            </div>
          </div>
        </div>

        <div className={`${darkMode ? 'bg-[#1a1a1a]' : 'bg-white'} rounded-2xl p-6 shadow-sm`}>
          <h3 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-lg mb-3`}>{t('additionalNotes')}</h3>
          <p className={`${darkMode ? 'text-gray-300' : 'text-[#1a1a1a]'} leading-relaxed`}>
            {t('exerciseAdvice')}
          </p>
        </div>
      </div>
    </div>
  );
}
