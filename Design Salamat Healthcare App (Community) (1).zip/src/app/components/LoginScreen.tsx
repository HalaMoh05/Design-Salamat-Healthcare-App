import { useState } from 'react';
import { useNavigate } from 'react-router';
import { Lock, Fingerprint, AlertCircle } from 'lucide-react';
import { useSettings } from '../context/SettingsContext';
import { BiometricModal } from './BiometricModal';
import { SalamatLogo } from './SalamatLogo';

export function LoginScreen() {
  const navigate = useNavigate();
  const { t, isRTL, darkMode } = useSettings();
  const [nationalId, setNationalId] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState({ nationalId: '', password: '' });
  const [isVerifying, setIsVerifying] = useState(false);
  const [verificationSuccess, setVerificationSuccess] = useState(false);
  const [showBiometric, setShowBiometric] = useState(false);

  const validateNationalId = (id: string) => {
    const regex = /^[0-9]{10}$/;
    return regex.test(id);
  };

  const validatePassword = (pass: string) => {
    return pass.length >= 6;
  };

  const handleLogin = () => {
    const newErrors = { nationalId: '', password: '' };

    if (!validateNationalId(nationalId)) {
      newErrors.nationalId = t('invalidNationalId');
    }

    if (!validatePassword(password)) {
      newErrors.password = t('invalidPassword');
    }

    setErrors(newErrors);

    if (!newErrors.nationalId && !newErrors.password) {
      setIsVerifying(true);
      setTimeout(() => {
        setVerificationSuccess(true);
        setTimeout(() => {
          navigate('/dashboard');
        }, 1500);
      }, 2000);
    }
  };

  const handleBiometricSuccess = () => {
    setShowBiometric(false);
    setIsVerifying(true);
    setTimeout(() => {
      setVerificationSuccess(true);
      setTimeout(() => {
        navigate('/dashboard');
      }, 1500);
    }, 2000);
  };

  return (
    <>
      <div className={`h-screen w-full ${darkMode ? 'bg-[#121212]' : 'bg-[#F5F7FA]'} flex flex-col items-center justify-center p-6`}>
        <div className="max-w-md w-full" dir={isRTL ? 'rtl' : 'ltr'}>
          <div className="flex flex-col items-center mb-8">
            <div className="mb-4">
              <SalamatLogo className="w-24 h-24" />
            </div>
            <h1 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-4xl mb-2`}>{t('loginTitle')}</h1>
            <p className={`${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} text-center`}>{t('loginSubtitle')}</p>
          </div>

          <div className={`${darkMode ? 'bg-[#1a1a1a]' : 'bg-white'} rounded-2xl p-6 shadow-sm mb-4`}>
            <div className="space-y-4">
              <div>
                <label className={`${darkMode ? 'text-gray-300' : 'text-[#1a1a1a]'} block mb-2`}>
                  {t('nationalId')}
                </label>
                <input
                  type="text"
                  value={nationalId}
                  onChange={(e) => setNationalId(e.target.value)}
                  placeholder="9851234567"
                  maxLength={10}
                  className={`w-full px-4 py-3 rounded-xl ${
                    darkMode
                      ? 'bg-[#2a2a2a] text-white border-gray-700'
                      : 'bg-[#F5F7FA] text-[#1a1a1a] border-[#E5E7EB]'
                  } border focus:outline-none focus:ring-2 focus:ring-[#2F80ED]`}
                  dir="ltr"
                />
                {errors.nationalId && (
                  <div className="flex items-center gap-2 mt-2 text-[#EB5757] text-sm">
                    <AlertCircle className="w-4 h-4" />
                    <span>{errors.nationalId}</span>
                  </div>
                )}
              </div>

              <div>
                <label className={`${darkMode ? 'text-gray-300' : 'text-[#1a1a1a]'} block mb-2`}>
                  {t('password')}
                </label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••"
                  className={`w-full px-4 py-3 rounded-xl ${
                    darkMode
                      ? 'bg-[#2a2a2a] text-white border-gray-700'
                      : 'bg-[#F5F7FA] text-[#1a1a1a] border-[#E5E7EB]'
                  } border focus:outline-none focus:ring-2 focus:ring-[#2F80ED]`}
                />
                {errors.password && (
                  <div className="flex items-center gap-2 mt-2 text-[#EB5757] text-sm">
                    <AlertCircle className="w-4 h-4" />
                    <span>{errors.password}</span>
                  </div>
                )}
              </div>
            </div>

            <button
              onClick={handleLogin}
              disabled={isVerifying}
              className="w-full bg-[#2F80ED] text-white py-4 px-6 rounded-xl mt-6 hover:bg-[#1E5BB8] transition-colors disabled:opacity-50"
            >
              {t('loginButton')}
            </button>
          </div>

          <button
            onClick={() => setShowBiometric(true)}
            className={`w-full ${darkMode ? 'bg-[#1a1a1a] border-gray-700' : 'bg-white border-[#E5E7EB]'} border-2 py-4 px-6 rounded-2xl flex items-center justify-center gap-3 mb-6 hover:border-[#2F80ED] transition-colors`}
          >
            <Fingerprint className="w-6 h-6 text-[#2F80ED]" />
            <span className={`${darkMode ? 'text-gray-300' : 'text-[#1a1a1a]'} text-lg`}>{t('biometricLogin')}</span>
          </button>

          <div className={`${darkMode ? 'bg-[#1a1a1a]' : 'bg-white'} rounded-2xl p-6 shadow-sm`}>
            <div className="flex items-start gap-3">
              <Lock className="w-5 h-5 text-[#2F80ED] mt-0.5 flex-shrink-0" />
              <p className={`${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} text-sm leading-relaxed`}>
                {t('securityMessage')}
              </p>
            </div>
          </div>

          {isVerifying && !verificationSuccess && (
            <div className="mt-4 bg-[#2F80ED]/10 border-2 border-[#2F80ED] rounded-xl p-4">
              <p className="text-[#2F80ED] text-center">{t('verifyingCredentials')}</p>
            </div>
          )}

          {verificationSuccess && (
            <div className="mt-4 bg-[#27AE60]/10 border-2 border-[#27AE60] rounded-xl p-4">
              <p className="text-[#27AE60] text-center">{t('verificationSuccessful')}</p>
            </div>
          )}
        </div>
      </div>

      <BiometricModal
        isOpen={showBiometric}
        onClose={() => setShowBiometric(false)}
        onSuccess={handleBiometricSuccess}
      />
    </>
  );
}
