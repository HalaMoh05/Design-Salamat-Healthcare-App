import { useEffect } from 'react';
import { CheckCircle2, AlertCircle, XCircle, Loader2 } from 'lucide-react';
import { useSettings } from '../context/SettingsContext';

export type ToastType = 'success' | 'error' | 'loading' | 'info';

interface ToastProps {
  message: string;
  type: ToastType;
  onClose: () => void;
  duration?: number;
}

export function Toast({ message, type, onClose, duration = 3000 }: ToastProps) {
  const { darkMode } = useSettings();

  useEffect(() => {
    if (type !== 'loading' && duration > 0) {
      const timer = setTimeout(onClose, duration);
      return () => clearTimeout(timer);
    }
  }, [type, duration, onClose]);

  const getIcon = () => {
    switch (type) {
      case 'success':
        return <CheckCircle2 className="w-5 h-5 text-[#27AE60]" />;
      case 'error':
        return <XCircle className="w-5 h-5 text-[#EB5757]" />;
      case 'loading':
        return <Loader2 className="w-5 h-5 text-[#2F80ED] animate-spin" />;
      default:
        return <AlertCircle className="w-5 h-5 text-[#2F80ED]" />;
    }
  };

  const getBgColor = () => {
    if (darkMode) {
      switch (type) {
        case 'success':
          return 'bg-[#27AE60]/20 border-[#27AE60]';
        case 'error':
          return 'bg-[#EB5757]/20 border-[#EB5757]';
        case 'loading':
          return 'bg-[#2F80ED]/20 border-[#2F80ED]';
        default:
          return 'bg-[#2F80ED]/20 border-[#2F80ED]';
      }
    } else {
      switch (type) {
        case 'success':
          return 'bg-[#27AE60]/10 border-[#27AE60]';
        case 'error':
          return 'bg-[#EB5757]/10 border-[#EB5757]';
        case 'loading':
          return 'bg-[#2F80ED]/10 border-[#2F80ED]';
        default:
          return 'bg-[#2F80ED]/10 border-[#2F80ED]';
      }
    }
  };

  return (
    <div className="fixed top-20 left-1/2 transform -translate-x-1/2 z-50 animate-in fade-in slide-in-from-top-5 duration-300">
      <div className={`${getBgColor()} border-2 rounded-xl px-6 py-4 shadow-lg flex items-center gap-3 min-w-[280px] max-w-md`}>
        {getIcon()}
        <p className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} flex-1`}>{message}</p>
      </div>
    </div>
  );
}
