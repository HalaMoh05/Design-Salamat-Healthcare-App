export function SalamatLogo({ className = "w-24 h-24" }: { className?: string }) {
  return (
    <svg
      className={className}
      viewBox="0 0 200 200"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        <linearGradient id="heartGradient" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#5BA4F5" />
          <stop offset="100%" stopColor="#3B82F6" />
        </linearGradient>
      </defs>

      {/* Outer heart */}
      <path
        d="M100 170C100 170 30 130 30 80C30 60 45 45 65 45C80 45 90 55 100 70C110 55 120 45 135 45C155 45 170 60 170 80C170 130 100 170 100 170Z"
        stroke="url(#heartGradient)"
        strokeWidth="12"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
      />

      {/* Inner checkmark heart */}
      <path
        d="M85 95L95 105L115 85"
        stroke="url(#heartGradient)"
        strokeWidth="10"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
      />
    </svg>
  );
}
