import { useNavigate } from 'react-router';
import { CheckCircle2, FileText, TestTube2, TrendingUp, Bell, ChevronLeft, Shield, User, Clock } from 'lucide-react';
import { useSettings } from '../context/SettingsContext';

export function Dashboard() {
  const navigate = useNavigate();
  const { t, isRTL, darkMode } = useSettings();

  const healthInsights = [
    {
      id: 1,
      image: '🫀',
      title: 'أهمية الكوليسترول الجيد لصحة القلب',
      description: 'تعرف على دور الكوليسترول الجيد في حماية القلب والشرايين',
      type: 'مقال طبي',
      verified: true
    },
    {
      id: 2,
      image: '🥗',
      title: 'نظام غذائي صحي لخفض الكوليسترول',
      description: 'إرشادات غذائية مبنية على أحدث الأبحاث الطبية',
      type: 'دليل غذائي',
      verified: true
    },
    {
      id: 3,
      image: '🏃',
      title: 'التمارين الرياضية وتأثيرها على السكر',
      description: 'دراسة حديثة عن العلاقة بين النشاط البدني ومستوى السكر',
      type: 'دراسة طبية',
      verified: true
    },
  ];

  return (
    <div className={`pb-20 ${darkMode ? 'bg-[#121212]' : 'bg-[#F5F7FA]'}`} dir={isRTL ? 'rtl' : 'ltr'}>
      <div className={`${darkMode ? 'bg-[#1a1a1a] border-gray-800' : 'bg-white border-[#E5E7EB]'} px-6 py-4 flex items-center justify-between border-b`}>
        <div className="flex items-center">
          <h1 className="text-[#2F80ED] text-xl">Salamat</h1>
        </div>
        <div className="flex items-center gap-3">
          <button onClick={() => navigate('/notifications')} className="relative p-2">
            <Bell className="w-6 h-6 text-[#2F80ED]" />
            <div className={`absolute ${isRTL ? 'right-1' : 'left-1'} top-1 w-2 h-2 bg-[#EB5757] rounded-full`} />
          </button>
          <div className="flex items-center gap-2 bg-[#2F80ED]/10 px-3 py-1.5 rounded-full">
            <CheckCircle2 className="w-4 h-4 text-[#2F80ED]" />
            <span className="text-[#2F80ED] text-sm">{t('welcomeBack')}</span>
          </div>
          <button onClick={() => navigate('/profile')} className="p-2">
            <User className="w-6 h-6 text-[#2F80ED]" />
          </button>
        </div>
      </div>

      <div className="px-6 py-6 space-y-4">
        <div className={`${darkMode ? 'bg-[#2F80ED]/20' : 'bg-[#E3F2FD]'} rounded-2xl p-4 flex items-center justify-between`}>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#2F80ED]/10 flex items-center justify-center">
              <Bell className="w-5 h-5 text-[#2F80ED]" />
            </div>
            <span className="text-[#2F80ED]">{t('newTestAdded')}</span>
          </div>
          <ChevronLeft className={`w-5 h-5 text-[#2F80ED] ${isRTL ? '' : 'rotate-180'}`} />
        </div>

        <div className={`${darkMode ? 'bg-[#1a1a1a]' : 'bg-white'} rounded-2xl p-6 shadow-sm`}>
          <div className="flex items-start justify-between mb-4">
            <div className="flex-1">
              <h3 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-xl mb-1`}>{t('healthStatus')}</h3>
              <div className="flex items-center gap-2 text-[#27AE60]">
                <span>{t('stable')}</span>
              </div>
            </div>
            <div className="w-14 h-14 rounded-2xl bg-[#27AE60]/10 flex items-center justify-center flex-shrink-0">
              <Shield className="w-8 h-8 text-[#27AE60]" />
            </div>
          </div>

          <div className={`grid grid-cols-2 gap-4 pt-4 border-t ${darkMode ? 'border-gray-800' : 'border-[#E5E7EB]'}`}>
            <div>
              <p className={`${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} text-sm mb-1`}>{t('lastUpdate')}</p>
              <p className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'}`}>
                {isRTL ? 'الجمعة 10:30 صباحًا' : 'Friday 10:30 AM'}
              </p>
            </div>
            <div>
              <p className={`${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} text-sm mb-1`}>{t('referenceNumber')}</p>
              <p className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'}`}>SA-992031</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-4 gap-3">
          <button
            onClick={() => navigate('/records')}
            className={`${darkMode ? 'bg-[#1a1a1a]' : 'bg-white'} rounded-2xl p-4 shadow-sm flex flex-col items-center gap-2 hover:shadow-md transition-shadow`}
          >
            <div className="w-12 h-12 rounded-xl bg-[#2F80ED]/10 flex items-center justify-center">
              <FileText className="w-6 h-6 text-[#2F80ED]" />
            </div>
            <span className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-xs text-center`}>{t('medicalRecord')}</span>
          </button>
          <button
            onClick={() => navigate('/charts')}
            className={`${darkMode ? 'bg-[#1a1a1a]' : 'bg-white'} rounded-2xl p-4 shadow-sm flex flex-col items-center gap-2 hover:shadow-md transition-shadow`}
          >
            <div className="w-12 h-12 rounded-xl bg-[#2F80ED]/10 flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-[#2F80ED]" />
            </div>
            <span className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-xs text-center`}>{t('charts')}</span>
          </button>
          <button
            onClick={() => navigate('/lab-results')}
            className={`${darkMode ? 'bg-[#1a1a1a]' : 'bg-white'} rounded-2xl p-4 shadow-sm flex flex-col items-center gap-2 hover:shadow-md transition-shadow`}
          >
            <div className="w-12 h-12 rounded-xl bg-[#2F80ED]/10 flex items-center justify-center">
              <TestTube2 className="w-6 h-6 text-[#2F80ED]" />
            </div>
            <span className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-xs text-center`}>{t('tests')}</span>
          </button>
          <button
            onClick={() => navigate('/notifications')}
            className={`${darkMode ? 'bg-[#1a1a1a]' : 'bg-white'} rounded-2xl p-4 shadow-sm flex flex-col items-center gap-2 hover:shadow-md transition-shadow relative`}
          >
            <div className="w-12 h-12 rounded-xl bg-[#2F80ED]/10 flex items-center justify-center">
              <Bell className="w-6 h-6 text-[#2F80ED]" />
            </div>
            <span className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-xs text-center`}>{t('notifications')}</span>
            <div className={`absolute top-3 ${isRTL ? 'left-3' : 'right-3'} w-2 h-2 bg-[#EB5757] rounded-full`} />
          </button>
        </div>

        <div>
          <div className="flex items-center justify-between mb-3">
            <h3 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-lg`}>{t('latestUpdates')}</h3>
            <button className="text-[#2F80ED] text-sm">{t('viewAll')}</button>
          </div>
          <div className="space-y-3">
            <button
              onClick={() => navigate('/visit/1')}
              className={`${darkMode ? 'bg-[#1a1a1a]' : 'bg-white'} rounded-2xl p-4 shadow-sm w-full flex items-center gap-3 hover:shadow-md transition-shadow`}
            >
              <div className={`w-10 h-10 rounded-xl ${darkMode ? 'bg-gray-800' : 'bg-[#F5F7FA]'} flex items-center justify-center flex-shrink-0`}>
                <FileText className={`w-5 h-5 ${darkMode ? 'text-gray-400' : 'text-[#6B7280]'}`} />
              </div>
              <div className="flex-1">
                <p className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} mb-1`}>{t('lastLabTest')}</p>
                <p className={`${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} text-sm`}>
                  {isRTL ? '15 أبريل 2023' : 'April 15, 2023'}
                </p>
              </div>
              <ChevronLeft className={`w-5 h-5 ${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} flex-shrink-0 ${isRTL ? '' : 'rotate-180'}`} />
            </button>
            <button
              onClick={() => navigate('/visit/2')}
              className={`${darkMode ? 'bg-[#1a1a1a]' : 'bg-white'} rounded-2xl p-4 shadow-sm w-full flex items-center gap-3 hover:shadow-md transition-shadow`}
            >
              <div className={`w-10 h-10 rounded-xl ${darkMode ? 'bg-gray-800' : 'bg-[#F5F7FA]'} flex items-center justify-center flex-shrink-0`}>
                <Clock className={`w-5 h-5 ${darkMode ? 'text-gray-400' : 'text-[#6B7280]'}`} />
              </div>
              <div className="flex-1">
                <p className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} mb-1`}>{t('lastVisit')}</p>
                <p className={`${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} text-sm`}>
                  {isRTL ? '10 أبريل 2023' : 'April 10, 2023'}
                </p>
              </div>
              <ChevronLeft className={`w-5 h-5 ${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} flex-shrink-0 ${isRTL ? '' : 'rotate-180'}`} />
            </button>
          </div>
        </div>

        <div>
          <h3 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-lg mb-4`}>{t('healthContent')}</h3>
          <div className="flex gap-4 overflow-x-auto pb-4">
            {healthInsights.map((insight) => (
              <div
                key={insight.id}
                className={`${darkMode ? 'bg-[#1a1a1a]' : 'bg-white'} rounded-2xl p-4 shadow-sm min-w-[280px] flex-shrink-0`}
              >
                <div className="text-5xl mb-3">{insight.image}</div>
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-xs bg-[#2F80ED]/10 text-[#2F80ED] px-2 py-1 rounded-full">
                    {insight.type}
                  </span>
                  {insight.verified && (
                    <CheckCircle2 className="w-4 h-4 text-[#27AE60]" />
                  )}
                </div>
                <h4 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} mb-2`}>{insight.title}</h4>
                <p className={`${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} text-sm mb-3 line-clamp-2`}>{insight.description}</p>
                <button className="flex items-center gap-2 text-[#2F80ED] text-sm">
                  <span>{t('readMore')}</span>
                  <ChevronLeft className={`w-4 h-4 ${isRTL ? '' : 'rotate-180'}`} />
                </button>
              </div>
            ))}
          </div>
          <div className={`mt-4 flex items-center justify-center gap-2 ${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} text-sm`}>
            <CheckCircle2 className="w-4 h-4 text-[#27AE60]" />
            <span>{t('verifiedContent')}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
