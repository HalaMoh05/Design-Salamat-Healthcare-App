import { useEffect } from 'react';
import { useNavigate } from 'react-router';
import { CheckCircle2, ShieldCheck } from 'lucide-react';
import { useSettings } from '../context/SettingsContext';

export function IdentityVerifiedScreen() {
  const navigate = useNavigate();
  const { t, isRTL, darkMode } = useSettings();

  useEffect(() => {
    const timer = setTimeout(() => {
      navigate('/dashboard');
    }, 2500);
    return () => clearTimeout(timer);
  }, [navigate]);

  return (
    <div className={`h-screen w-full ${darkMode ? 'bg-[#121212]' : 'bg-[#F5F7FA]'} flex flex-col items-center justify-center p-6`}>
      <div className="max-w-md w-full flex flex-col items-center">
        <div className="bg-[#27AE60] rounded-full p-6 mb-6 animate-pulse">
          <CheckCircle2 className="w-20 h-20 text-white" />
        </div>

        <h2 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-3xl mb-4`}>
          {isRTL ? 'تم التحقق من الهوية' : 'Identity Verified'}
        </h2>

        <div className={`${darkMode ? 'bg-[#1a1a1a]' : 'bg-white'} rounded-2xl p-6 w-full shadow-sm mb-4`} dir={isRTL ? 'rtl' : 'ltr'}>
          <div className="flex items-center justify-between mb-3">
            <span className={darkMode ? 'text-gray-400' : 'text-[#6B7280]'}>
              {isRTL ? 'الاسم' : 'Name'}
            </span>
            <span className={darkMode ? 'text-white' : 'text-[#1a1a1a]'}>
              {isRTL ? 'محمد أحمد الخطيب' : 'Mohammad Ahmad Al-Khatib'}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className={darkMode ? 'text-gray-400' : 'text-[#6B7280]'}>
              {isRTL ? 'الرقم الوطني' : 'National ID'}
            </span>
            <span className={darkMode ? 'text-white' : 'text-[#1a1a1a]'}>****4567</span>
          </div>
        </div>

        <div className="flex items-center gap-2 text-[#27AE60]">
          <ShieldCheck className="w-5 h-5" />
          <span>{isRTL ? 'تم التحقق بنجاح عبر نظام سند' : 'Successfully verified via Sanad system'}</span>
        </div>
      </div>
    </div>
  );
}
