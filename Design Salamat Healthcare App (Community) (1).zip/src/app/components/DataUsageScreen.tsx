import { useNavigate } from 'react-router';
import { ArrowRight, Download, FileText, User, Calendar, MapPin, Phone, Mail, TestTube2, Stethoscope } from 'lucide-react';
import { useSettings } from '../context/SettingsContext';

export function DataUsageScreen() {
  const navigate = useNavigate();
  const { t, isRTL, darkMode } = useSettings();

  const handleDownload = (format: 'pdf' | 'word') => {
    const message = isRTL
      ? `جاري تحميل السجل الصحي بصيغة ${format === 'pdf' ? 'PDF' : 'Word'}...`
      : `Downloading health record as ${format === 'pdf' ? 'PDF' : 'Word'}...`;
    alert(message);
  };

  return (
    <div className={`pb-20 ${darkMode ? 'bg-[#121212]' : 'bg-[#F5F7FA]'}`} dir={isRTL ? 'rtl' : 'ltr'}>
      <div className={`${darkMode ? 'bg-[#1a1a1a] border-gray-800' : 'bg-white border-[#E5E7EB]'} px-6 py-4 flex items-center gap-3 border-b sticky top-0 z-10`}>
        <button onClick={() => navigate('/settings')} className="p-2">
          <ArrowRight className={`w-6 h-6 ${darkMode ? 'text-white' : 'text-[#1a1a1a]'} ${isRTL ? '' : 'rotate-180'}`} />
        </button>
        <h2 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-xl flex-1`}>{t('dataUsageTitle')}</h2>
      </div>

      <div className="px-6 py-6 space-y-6">
        <div className={`bg-gradient-to-br ${darkMode ? 'from-[#2F80ED]/20 to-[#2F80ED]/10' : 'from-[#2F80ED]/10 to-[#2F80ED]/5'} rounded-2xl p-6`}>
          <h3 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-lg mb-3`}>{t('completeHealthRecord')}</h3>
          <p className={`${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} mb-4`}>
            {t('downloadDescription')}
          </p>
          <div className="flex gap-3">
            <button
              onClick={() => handleDownload('pdf')}
              className="flex-1 bg-[#EB5757] text-white py-3 px-4 rounded-xl flex items-center justify-center gap-2 hover:bg-[#EB5757]/90 transition-colors"
            >
              <Download className="w-5 h-5" />
              <span>{t('downloadPDF')}</span>
            </button>
            <button
              onClick={() => handleDownload('word')}
              className="flex-1 bg-[#2F80ED] text-white py-3 px-4 rounded-xl flex items-center justify-center gap-2 hover:bg-[#2F80ED]/90 transition-colors"
            >
              <Download className="w-5 h-5" />
              <span>{t('downloadWord')}</span>
            </button>
          </div>
        </div>

        <div className={`${darkMode ? 'bg-[#1a1a1a]' : 'bg-white'} rounded-2xl p-6 shadow-sm`}>
          <h3 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-lg mb-4`}>{t('personalInfo')}</h3>
          <div className="space-y-4">
            <div className="flex items-start gap-3">
              <User className="w-5 h-5 text-[#2F80ED] mt-0.5" />
              <div className="flex-1">
                <p className={`${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} text-sm mb-1`}>{t('fullName')}</p>
                <p className={darkMode ? 'text-white' : 'text-[#1a1a1a]'}>
                  {isRTL ? 'محمد أحمد الخطيب' : 'Mohammad Ahmad Al-Khatib'}
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <FileText className="w-5 h-5 text-[#2F80ED] mt-0.5" />
              <div className="flex-1">
                <p className={`${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} text-sm mb-1`}>{t('nationalIdNum')}</p>
                <p className={darkMode ? 'text-white' : 'text-[#1a1a1a]'}>9851234567</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Calendar className="w-5 h-5 text-[#2F80ED] mt-0.5" />
              <div className="flex-1">
                <p className={`${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} text-sm mb-1`}>{t('dateOfBirth')}</p>
                <p className={darkMode ? 'text-white' : 'text-[#1a1a1a]'}>
                  {isRTL ? '15 يناير 1985' : 'January 15, 1985'}
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Phone className="w-5 h-5 text-[#2F80ED] mt-0.5" />
              <div className="flex-1">
                <p className={`${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} text-sm mb-1`}>{t('phoneNumber')}</p>
                <p className={darkMode ? 'text-white' : 'text-[#1a1a1a]'} dir="ltr">+962 79 123 4567</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Mail className="w-5 h-5 text-[#2F80ED] mt-0.5" />
              <div className="flex-1">
                <p className={`${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} text-sm mb-1`}>{t('email')}</p>
                <p className={darkMode ? 'text-white' : 'text-[#1a1a1a]'} dir="ltr">mohammad.khatib@email.com</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <MapPin className="w-5 h-5 text-[#2F80ED] mt-0.5" />
              <div className="flex-1">
                <p className={`${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} text-sm mb-1`}>{t('address')}</p>
                <p className={darkMode ? 'text-white' : 'text-[#1a1a1a]'}>{t('ammanJordan')}</p>
              </div>
            </div>
          </div>
        </div>

        <div className={`${darkMode ? 'bg-[#1a1a1a]' : 'bg-white'} rounded-2xl p-6 shadow-sm`}>
          <h3 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-lg mb-4`}>{t('usageStatistics')}</h3>
          <div className="grid grid-cols-2 gap-4">
            <div className={`p-4 ${darkMode ? 'bg-gray-800' : 'bg-[#F5F7FA]'} rounded-xl`}>
              <div className="flex items-center gap-2 mb-2">
                <Stethoscope className="w-5 h-5 text-[#2F80ED]" />
                <span className={`${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} text-sm`}>{t('visits')}</span>
              </div>
              <p className={`text-2xl ${darkMode ? 'text-white' : 'text-[#1a1a1a]'}`}>12</p>
            </div>
            <div className={`p-4 ${darkMode ? 'bg-gray-800' : 'bg-[#F5F7FA]'} rounded-xl`}>
              <div className="flex items-center gap-2 mb-2">
                <TestTube2 className="w-5 h-5 text-[#2F80ED]" />
                <span className={`${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} text-sm`}>{t('labTests')}</span>
              </div>
              <p className={`text-2xl ${darkMode ? 'text-white' : 'text-[#1a1a1a]'}`}>24</p>
            </div>
          </div>
        </div>

        <div className={`${darkMode ? 'bg-[#1a1a1a]' : 'bg-white'} rounded-2xl p-6 shadow-sm`}>
          <h3 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-lg mb-4`}>{t('healthInfo')}</h3>
          <div className="space-y-3">
            <div className={`flex items-center justify-between pb-3 border-b ${darkMode ? 'border-gray-800' : 'border-[#E5E7EB]'}`}>
              <span className={darkMode ? 'text-gray-400' : 'text-[#6B7280]'}>{t('bloodType')}</span>
              <span className={darkMode ? 'text-white' : 'text-[#1a1a1a]'}>O+</span>
            </div>
            <div className={`flex items-center justify-between pb-3 border-b ${darkMode ? 'border-gray-800' : 'border-[#E5E7EB]'}`}>
              <span className={darkMode ? 'text-gray-400' : 'text-[#6B7280]'}>{t('height')}</span>
              <span className={darkMode ? 'text-white' : 'text-[#1a1a1a]'}>
                {isRTL ? '175 سم' : '175 cm'}
              </span>
            </div>
            <div className={`flex items-center justify-between pb-3 border-b ${darkMode ? 'border-gray-800' : 'border-[#E5E7EB]'}`}>
              <span className={darkMode ? 'text-gray-400' : 'text-[#6B7280]'}>{t('weight')}</span>
              <span className={darkMode ? 'text-white' : 'text-[#1a1a1a]'}>
                {isRTL ? '78 كغ' : '78 kg'}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className={darkMode ? 'text-gray-400' : 'text-[#6B7280]'}>{t('generalHealthStatus')}</span>
              <span className="text-[#27AE60]">{t('good')}</span>
            </div>
          </div>
        </div>

        <div className={`${darkMode ? 'bg-[#1a1a1a]' : 'bg-white'} rounded-2xl p-6 shadow-sm`}>
          <h3 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-lg mb-4`}>{t('latestUpdates')}</h3>
          <div className="space-y-3">
            <div className={`p-3 ${darkMode ? 'bg-gray-800' : 'bg-[#F5F7FA]'} rounded-xl`}>
              <p className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} mb-1`}>{t('lastVisit')}</p>
              <p className={`${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} text-sm`}>
                {isRTL ? '15 أبريل 2026 - مستشفى البشير' : 'April 15, 2026 - Al-Bashir Hospital'}
              </p>
            </div>
            <div className={`p-3 ${darkMode ? 'bg-gray-800' : 'bg-[#F5F7FA]'} rounded-xl`}>
              <p className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} mb-1`}>{t('lastTest')}</p>
              <p className={`${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} text-sm`}>
                {isRTL ? '20 أبريل 2026 - مختبرات البيوكيمياء' : 'April 20, 2026 - Medical Biochemistry Labs'}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
