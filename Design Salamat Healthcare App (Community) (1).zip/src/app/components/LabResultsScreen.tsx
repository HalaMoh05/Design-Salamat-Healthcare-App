import { useNavigate } from 'react-router';
import { ArrowRight, ChevronLeft, Calendar, CheckCircle2, AlertTriangle } from 'lucide-react';
import { useSettings } from '../context/SettingsContext';

export function LabResultsScreen() {
  const navigate = useNavigate();
  const { t, isRTL, darkMode } = useSettings();

  const results = [
    {
      id: 1,
      nameAr: 'تحليل الدم الشامل',
      nameEn: 'Complete Blood Count',
      dateAr: '20 أبريل 2026',
      dateEn: 'April 20, 2026',
      status: 'normal'
    },
    {
      id: 2,
      nameAr: 'تحليل السكر التراكمي',
      nameEn: 'HbA1c Test',
      dateAr: '18 أبريل 2026',
      dateEn: 'April 18, 2026',
      status: 'normal'
    },
    {
      id: 3,
      nameAr: 'تحليل الكوليسترول',
      nameEn: 'Cholesterol Test',
      dateAr: '18 أبريل 2026',
      dateEn: 'April 18, 2026',
      status: 'warning'
    },
    {
      id: 4,
      nameAr: 'تحليل وظائف الكلى',
      nameEn: 'Kidney Function Test',
      dateAr: '10 أبريل 2026',
      dateEn: 'April 10, 2026',
      status: 'normal'
    },
    {
      id: 5,
      nameAr: 'تحليل وظائف الكبد',
      nameEn: 'Liver Function Test',
      dateAr: '10 أبريل 2026',
      dateEn: 'April 10, 2026',
      status: 'normal'
    },
    {
      id: 6,
      nameAr: 'تحليل فيتامين د',
      nameEn: 'Vitamin D Test',
      dateAr: '5 أبريل 2026',
      dateEn: 'April 5, 2026',
      status: 'warning'
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'normal':
        return 'bg-[#27AE60]';
      case 'warning':
        return 'bg-[#F2C94C]';
      case 'critical':
        return 'bg-[#EB5757]';
      default:
        return 'bg-[#6B7280]';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'normal':
        return <CheckCircle2 className="w-5 h-5 text-[#27AE60]" />;
      case 'warning':
        return <AlertTriangle className="w-5 h-5 text-[#F2C94C]" />;
      case 'critical':
        return <AlertTriangle className="w-5 h-5 text-[#EB5757]" />;
      default:
        return null;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'normal':
        return t('normal');
      case 'warning':
        return t('warning');
      case 'critical':
        return t('critical');
      default:
        return '';
    }
  };

  return (
    <div className={`pb-20 ${darkMode ? 'bg-[#121212]' : 'bg-[#F5F7FA]'}`} dir={isRTL ? 'rtl' : 'ltr'}>
      <div className={`${darkMode ? 'bg-[#1a1a1a] border-gray-800' : 'bg-white border-[#E5E7EB]'} px-6 py-4 flex items-center gap-3 border-b sticky top-0 z-10`}>
        <button onClick={() => navigate('/dashboard')} className="p-2">
          <ArrowRight className={`w-6 h-6 ${darkMode ? 'text-white' : 'text-[#1a1a1a]'} ${isRTL ? '' : 'rotate-180'}`} />
        </button>
        <h2 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-xl flex-1`}>{t('labResults')}</h2>
      </div>

      <div className="px-6 py-6 space-y-3">
        {results.map((result) => (
          <button
            key={result.id}
            onClick={() => navigate(`/analysis/${result.id}`)}
            className={`${darkMode ? 'bg-[#1a1a1a]' : 'bg-white'} rounded-2xl p-5 shadow-sm w-full hover:shadow-md transition-shadow`}
          >
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <h3 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-lg mb-2`}>
                  {isRTL ? result.nameAr : result.nameEn}
                </h3>
                <div className={`flex items-center gap-2 ${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} text-sm mb-3`}>
                  <Calendar className="w-4 h-4" />
                  <span>{isRTL ? result.dateAr : result.dateEn}</span>
                </div>
                <div className="flex items-center gap-2">
                  {getStatusIcon(result.status)}
                  <span className={`text-sm ${result.status === 'normal' ? 'text-[#27AE60]' : result.status === 'warning' ? 'text-[#F2C94C]' : 'text-[#EB5757]'}`}>
                    {getStatusText(result.status)}
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-3 flex-shrink-0">
                <div className={`w-3 h-3 rounded-full ${getStatusColor(result.status)}`} />
                <ChevronLeft className={`w-5 h-5 ${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} ${isRTL ? '' : 'rotate-180'}`} />
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
