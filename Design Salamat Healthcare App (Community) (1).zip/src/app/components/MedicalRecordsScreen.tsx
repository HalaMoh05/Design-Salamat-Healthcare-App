import { useNavigate } from 'react-router';
import { ArrowRight, ChevronLeft, Calendar, User } from 'lucide-react';
import { useSettings } from '../context/SettingsContext';

export function MedicalRecordsScreen() {
  const navigate = useNavigate();
  const { t, isRTL, darkMode } = useSettings();

  const records = [
    {
      id: 1,
      dateAr: '15 أبريل 2026',
      dateEn: 'April 15, 2026',
      type: t('cardiology'),
      doctor: t('drAhmadHamoud'),
      description: t('routineCardiacExam')
    },
    {
      id: 2,
      dateAr: '8 أبريل 2026',
      dateEn: 'April 8, 2026',
      type: t('generalCheckup'),
      doctor: t('drSarahKhatib'),
      description: t('annualCheckup')
    },
    {
      id: 3,
      dateAr: '22 مارس 2026',
      dateEn: 'March 22, 2026',
      type: t('dermatology'),
      doctor: t('drKhaledNusour'),
      description: t('allergyFollowup')
    },
    {
      id: 4,
      dateAr: '10 مارس 2026',
      dateEn: 'March 10, 2026',
      type: t('ophthalmology'),
      doctor: t('drLaylaOmari'),
      description: t('visionTest')
    }
  ];

  return (
    <div className={`pb-20 ${darkMode ? 'bg-[#121212]' : 'bg-[#F5F7FA]'}`} dir={isRTL ? 'rtl' : 'ltr'}>
      <div className={`${darkMode ? 'bg-[#1a1a1a] border-gray-800' : 'bg-white border-[#E5E7EB]'} px-6 py-4 flex items-center gap-3 border-b sticky top-0 z-10`}>
        <button onClick={() => navigate('/dashboard')} className="p-2">
          <ArrowRight className={`w-6 h-6 ${darkMode ? 'text-white' : 'text-[#1a1a1a]'} ${isRTL ? '' : 'rotate-180'}`} />
        </button>
        <h2 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-xl flex-1`}>{t('medicalRecords')}</h2>
      </div>

      <div className="px-6 py-6 space-y-4">
        {records.map((record) => (
          <button
            key={record.id}
            onClick={() => navigate(`/visit/${record.id}`)}
            className={`${darkMode ? 'bg-[#1a1a1a]' : 'bg-white'} rounded-2xl p-5 shadow-sm w-full hover:shadow-md transition-shadow`}
          >
            <div className="flex items-start justify-between mb-3">
              <div className="flex-1">
                <h3 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-lg mb-1`}>{record.type}</h3>
                <div className={`flex items-center gap-2 ${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} text-sm mb-2`}>
                  <Calendar className="w-4 h-4" />
                  <span>{isRTL ? record.dateAr : record.dateEn}</span>
                </div>
                <div className={`flex items-center gap-2 ${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} text-sm`}>
                  <User className="w-4 h-4" />
                  <span>{record.doctor}</span>
                </div>
              </div>
              <ChevronLeft className={`w-5 h-5 ${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} flex-shrink-0 ${isRTL ? '' : 'rotate-180'}`} />
            </div>
            <p className={`${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} text-sm`}>{record.description}</p>
          </button>
        ))}
      </div>
    </div>
  );
}
