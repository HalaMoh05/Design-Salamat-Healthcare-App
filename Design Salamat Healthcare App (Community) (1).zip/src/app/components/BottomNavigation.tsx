import { useNavigate, useLocation } from 'react-router';
import { Home, FileText, TrendingUp, User, Settings } from 'lucide-react';
import { useSettings } from '../context/SettingsContext';

export function BottomNavigation() {
  const navigate = useNavigate();
  const location = useLocation();
  const { t, darkMode } = useSettings();

  const isActive = (path: string) => location.pathname === path;

  const navItems = [
    { path: '/dashboard', icon: Home, labelKey: 'home' as const },
    { path: '/records', icon: FileText, labelKey: 'records' as const },
    { path: '/charts', icon: TrendingUp, labelKey: 'graphsNav' as const },
    { path: '/profile', icon: User, labelKey: 'profileNav' as const },
    { path: '/settings', icon: Settings, labelKey: 'settingsNav' as const },
  ];

  return (
    <div className={`fixed bottom-0 left-0 right-0 ${darkMode ? 'bg-[#1a1a1a] border-gray-800' : 'bg-white border-[#E5E7EB]'} border-t z-20`}>
      <div className="max-w-md mx-auto flex items-center justify-around py-2">
        {navItems.map((item) => (
          <button
            key={item.path}
            onClick={() => navigate(item.path)}
            className={`flex flex-col items-center gap-1 py-2 px-4 rounded-xl transition-colors ${
              isActive(item.path)
                ? 'text-[#2F80ED]'
                : `${darkMode ? 'text-gray-400 hover:text-[#2F80ED]' : 'text-[#6B7280] hover:text-[#2F80ED]'}`
            }`}
          >
            <item.icon className="w-6 h-6" />
            <span className="text-xs">{t(item.labelKey)}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
