import { useNavigate } from 'react-router';
import { ArrowRight, TestTube2, Bell, Calendar, FileText } from 'lucide-react';
import { useSettings } from '../context/SettingsContext';

export function NotificationsScreen() {
  const navigate = useNavigate();
  const { t, isRTL, darkMode } = useSettings();

  const notifications = [
    {
      id: 1,
      icon: 'test',
      title: t('newResultAdded'),
      description: t('completeBloodTest'),
      time: t('hoursAgo'),
      unread: true
    },
    {
      id: 2,
      icon: 'reminder',
      title: t('doctorAppointmentReminder'),
      description: t('nextAppointment'),
      time: t('fiveHoursAgo'),
      unread: true
    },
    {
      id: 3,
      icon: 'test',
      title: t('cholesterolResults'),
      description: t('slightIncrease'),
      time: t('yesterday'),
      unread: false
    },
    {
      id: 4,
      icon: 'visit',
      title: t('newVisitRecorded'),
      description: `${isRTL ? 'زيارة عيادة القلب - د. أحمد الحمود' : 'Cardiology visit - Dr. Ahmad Al-Hamoud'}`,
      time: t('daysAgo'),
      unread: false
    },
    {
      id: 5,
      icon: 'reminder',
      title: t('medicationTime'),
      description: t('aspirin'),
      time: t('threeDaysAgo'),
      unread: false
    },
  ];

  const getIcon = (type: string) => {
    switch (type) {
      case 'test':
        return <TestTube2 className="w-6 h-6 text-[#2F80ED]" />;
      case 'reminder':
        return <Bell className="w-6 h-6 text-[#F2C94C]" />;
      case 'visit':
        return <FileText className="w-6 h-6 text-[#27AE60]" />;
      default:
        return <Bell className="w-6 h-6 text-[#6B7280]" />;
    }
  };

  return (
    <div className={`pb-20 ${darkMode ? 'bg-[#121212]' : 'bg-[#F5F7FA]'}`} dir={isRTL ? 'rtl' : 'ltr'}>
      <div className={`${darkMode ? 'bg-[#1a1a1a] border-gray-800' : 'bg-white border-[#E5E7EB]'} px-6 py-4 flex items-center gap-3 border-b sticky top-0 z-10`}>
        <button onClick={() => navigate('/dashboard')} className="p-2">
          <ArrowRight className={`w-6 h-6 ${darkMode ? 'text-white' : 'text-[#1a1a1a]'} ${isRTL ? '' : 'rotate-180'}`} />
        </button>
        <h2 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-xl flex-1`}>{t('notifications')}</h2>
      </div>

      <div className="px-6 py-6 space-y-3">
        {notifications.map((notification) => (
          <div
            key={notification.id}
            className={`${darkMode ? 'bg-[#1a1a1a]' : 'bg-white'} rounded-2xl p-5 shadow-sm ${notification.unread ? 'border-2 border-[#2F80ED]/20' : ''}`}
          >
            <div className="flex gap-4">
              <div className={`flex-shrink-0 w-12 h-12 rounded-full flex items-center justify-center ${
                notification.unread ? 'bg-[#2F80ED]/10' : `${darkMode ? 'bg-gray-800' : 'bg-[#F5F7FA]'}`
              }`}>
                {getIcon(notification.icon)}
              </div>
              <div className="flex-1">
                <div className="flex items-start justify-between mb-1">
                  <h3 className={darkMode ? 'text-white' : 'text-[#1a1a1a]'}>{notification.title}</h3>
                  {notification.unread && (
                    <div className="w-2 h-2 bg-[#2F80ED] rounded-full mt-2" />
                  )}
                </div>
                <p className={`${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} text-sm mb-2`}>{notification.description}</p>
                <div className={`flex items-center gap-2 ${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} text-xs`}>
                  <Calendar className="w-3 h-3" />
                  <span>{notification.time}</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
