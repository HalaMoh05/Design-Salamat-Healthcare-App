import { useNavigate } from 'react-router';
import { ArrowRight, FileText, TestTube2, Calendar } from 'lucide-react';

export function TimelineScreen() {
  const navigate = useNavigate();

  const timelineEvents = [
    {
      id: 1,
      type: 'test',
      title: 'تحليل الدم الشامل',
      date: '20 أبريل 2026',
      description: 'جميع النتائج ضمن المعدل الطبيعي',
      status: 'normal'
    },
    {
      id: 2,
      type: 'visit',
      title: 'زيارة عيادة القلب',
      date: '15 أبريل 2026',
      description: 'فحص دوري - د. أحمد الحمود',
      status: 'normal'
    },
    {
      id: 3,
      type: 'test',
      title: 'تحليل الكوليسترول',
      date: '18 أبريل 2026',
      description: 'ارتفاع بسيط في الكوليسترول',
      status: 'warning'
    },
    {
      id: 4,
      type: 'visit',
      title: 'فحص عام',
      date: '8 أبريل 2026',
      description: 'فحص سنوي شامل - د. فاطمة الزهراني',
      status: 'normal'
    },
    {
      id: 5,
      type: 'test',
      title: 'تحليل وظائف الكلى',
      date: '10 أبريل 2026',
      description: 'وظائف الكلى طبيعية',
      status: 'normal'
    },
    {
      id: 6,
      type: 'visit',
      title: 'استشارة جلدية',
      date: '22 مارس 2026',
      description: 'متابعة علاج الحساسية - د. خالد النسور',
      status: 'normal'
    },
  ];

  return (
    <div className="pb-20">
      <div className="bg-white px-6 py-4 flex items-center gap-3 border-b border-[#E5E7EB] sticky top-0 z-10">
        <button onClick={() => navigate('/dashboard')} className="p-2">
          <ArrowRight className="w-6 h-6 text-[#1a1a1a]" />
        </button>
        <h2 className="text-[#1a1a1a] text-xl flex-1">الجدول الزمني</h2>
      </div>

      <div className="px-6 py-6">
        <div className="relative">
          <div className="absolute right-6 top-0 bottom-0 w-0.5 bg-[#E5E7EB]" />

          <div className="space-y-6">
            {timelineEvents.map((event, index) => (
              <div key={event.id} className="relative flex gap-4">
                <div className={`flex-shrink-0 w-12 h-12 rounded-full flex items-center justify-center z-10 ${
                  event.status === 'normal' ? 'bg-[#27AE60]' : event.status === 'warning' ? 'bg-[#F2C94C]' : 'bg-[#2F80ED]'
                }`}>
                  {event.type === 'test' ? (
                    <TestTube2 className="w-6 h-6 text-white" />
                  ) : (
                    <FileText className="w-6 h-6 text-white" />
                  )}
                </div>

                <div className="flex-1 bg-white rounded-2xl p-5 shadow-sm">
                  <div className="flex items-center gap-2 mb-2">
                    <Calendar className="w-4 h-4 text-[#6B7280]" />
                    <span className="text-[#6B7280] text-sm">{event.date}</span>
                  </div>
                  <h3 className="text-[#1a1a1a] text-lg mb-1">{event.title}</h3>
                  <p className="text-[#6B7280] text-sm">{event.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
