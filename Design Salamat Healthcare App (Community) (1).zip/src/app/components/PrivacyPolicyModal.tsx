import { X } from 'lucide-react';
import { useSettings } from '../context/SettingsContext';

interface PrivacyPolicyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function PrivacyPolicyModal({ isOpen, onClose }: PrivacyPolicyModalProps) {
  const { isRTL, darkMode } = useSettings();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-6" onClick={onClose}>
      <div className={`${darkMode ? 'bg-[#1a1a1a]' : 'bg-white'} rounded-2xl max-w-md w-full max-h-[80vh] overflow-y-auto`} onClick={(e) => e.stopPropagation()} dir={isRTL ? 'rtl' : 'ltr'}>
        <div className={`sticky top-0 ${darkMode ? 'bg-[#1a1a1a] border-gray-800' : 'bg-white border-[#E5E7EB]'} border-b px-6 py-4 flex items-center justify-between`}>
          <h2 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-xl`}>
            {isRTL ? 'سياسة الخصوصية' : 'Privacy Policy'}
          </h2>
          <button onClick={onClose} className={`p-2 ${darkMode ? 'hover:bg-gray-800' : 'hover:bg-[#F5F7FA]'} rounded-lg`}>
            <X className={`w-5 h-5 ${darkMode ? 'text-gray-400' : 'text-[#6B7280]'}`} />
          </button>
        </div>

        <div className="px-6 py-6 space-y-4">
          <div>
            <h3 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-lg mb-2`}>
              {isRTL ? 'حماية بياناتك الصحية' : 'Protecting Your Health Data'}
            </h3>
            <p className={`${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} leading-relaxed`}>
              {isRTL
                ? 'نلتزم في تطبيق سلامات بحماية خصوصيتك وأمان معلوماتك الصحية. جميع البيانات الشخصية والطبية يتم تخزينها بتشفير عالي الأمان وفق أعلى المعايير العالمية. لا يتم مشاركة أي معلومات مع أي جهة خارجية دون موافقتك الصريحة والمسبقة.'
                : 'At Salamat, we are committed to protecting your privacy and the security of your health information. All personal and medical data is stored with high-level encryption according to the highest international standards. No information is shared with any third party without your explicit prior consent.'}
            </p>
          </div>

          <div>
            <h3 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-lg mb-2`}>
              {isRTL ? 'استخدام المعلومات' : 'Use of Information'}
            </h3>
            <p className={`${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} leading-relaxed`}>
              {isRTL
                ? 'يتم استخدام معلوماتك الصحية فقط لغرض تقديم الخدمة الطبية وتحسين تجربتك في التطبيق. يتم التحقق من هويتك عبر نظام سند الوطني لضمان أن جميع البيانات تخصك فقط. يمكنك في أي وقت طلب حذف بياناتك أو تصدير نسخة كاملة منها.'
                : 'Your health information is used only to provide medical services and improve your experience in the app. Your identity is verified through the national Sanad system to ensure all data belongs to you only. You can request deletion of your data or export a complete copy at any time.'}
            </p>
          </div>

          <div className={`pt-4 border-t ${darkMode ? 'border-gray-800' : 'border-[#E5E7EB]'}`}>
            <p className={`${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} text-sm`}>
              {isRTL ? 'آخر تحديث: 22 أبريل 2026' : 'Last updated: April 22, 2026'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
