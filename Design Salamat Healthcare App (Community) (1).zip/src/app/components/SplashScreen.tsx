import { useEffect } from 'react';
import { useNavigate } from 'react-router';
import { useSettings } from '../context/SettingsContext';
import { SalamatLogo } from './SalamatLogo';

export function SplashScreen() {
  const navigate = useNavigate();
  const { isRTL } = useSettings();

  useEffect(() => {
    const timer = setTimeout(() => {
      navigate('/login');
    }, 2500);

    return () => {
      clearTimeout(timer);
    };
  }, [navigate]);

  return (
    <div className="h-screen w-full relative overflow-hidden bg-gradient-to-b from-[#000000] via-[#0a1628] to-[#0f2744]" dir={isRTL ? 'rtl' : 'ltr'}>
      {/* Decorative waves at bottom */}
      <svg
        className="absolute bottom-0 right-0 w-full h-1/3 opacity-[0.03]"
        viewBox="0 0 1440 400"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        preserveAspectRatio="none"
      >
        <path
          d="M0 100C240 100 240 150 480 150C720 150 720 100 960 100C1200 100 1200 150 1440 150V400H0V100Z"
          fill="#3B82F6"
        />
        <path
          d="M0 180C240 180 240 230 480 230C720 230 720 180 960 180C1200 180 1200 230 1440 230V400H0V180Z"
          fill="#2563EB"
        />
        <path
          d="M0 260C240 260 240 310 480 310C720 310 720 260 960 260C1200 260 1200 310 1440 310V400H0V260Z"
          fill="#1E40AF"
        />
      </svg>

      {/* Main content */}
      <div className="relative z-10 h-full flex flex-col items-center justify-center px-8">
        {/* Logo */}
        <div className="mb-8">
          <SalamatLogo className="w-32 h-32" />
        </div>

        {/* App name */}
        <h1 className="text-white text-5xl mb-4" style={{ fontWeight: 700, letterSpacing: '0.02em' }}>
          {isRTL ? 'سلامات' : 'Salamat'}
        </h1>

        {/* Tagline */}
        <p className="text-gray-400 text-lg text-center max-w-sm">
          {isRTL ? 'منصة صحية متكاملة لرعايتك' : 'Integrated Healthcare Platform for Your Care'}
        </p>
      </div>
    </div>
  );
}
