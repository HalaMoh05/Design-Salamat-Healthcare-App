import { useNavigate } from 'react-router';
import { ArrowRight, TrendingUp } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { useSettings } from '../context/SettingsContext';

export function ChartsScreen() {
  const navigate = useNavigate();
  const { t, isRTL, darkMode } = useSettings();

  const glucoseData = [
    { dateAr: 'يناير', dateEn: 'January', value: 95 },
    { dateAr: 'فبراير', dateEn: 'February', value: 92 },
    { dateAr: 'مارس', dateEn: 'March', value: 98 },
    { dateAr: 'أبريل', dateEn: 'April', value: 94 },
  ].map(item => ({ ...item, date: isRTL ? item.dateAr : item.dateEn }));

  const bloodPressureData = [
    { dateAr: 'يناير', dateEn: 'January', systolic: 120, diastolic: 80 },
    { dateAr: 'فبراير', dateEn: 'February', systolic: 118, diastolic: 78 },
    { dateAr: 'مارس', dateEn: 'March', systolic: 122, diastolic: 82 },
    { dateAr: 'أبريل', dateEn: 'April', systolic: 119, diastolic: 79 },
  ].map(item => ({ ...item, date: isRTL ? item.dateAr : item.dateEn }));

  const cholesterolData = [
    { dateAr: 'يناير', dateEn: 'January', value: 180 },
    { dateAr: 'فبراير', dateEn: 'February', value: 185 },
    { dateAr: 'مارس', dateEn: 'March', value: 195 },
    { dateAr: 'أبريل', dateEn: 'April', value: 210 },
  ].map(item => ({ ...item, date: isRTL ? item.dateAr : item.dateEn }));

  return (
    <div className={`pb-20 ${darkMode ? 'bg-[#121212]' : 'bg-[#F5F7FA]'}`} dir={isRTL ? 'rtl' : 'ltr'}>
      <div className={`${darkMode ? 'bg-[#1a1a1a] border-gray-800' : 'bg-white border-[#E5E7EB]'} px-6 py-4 flex items-center gap-3 border-b sticky top-0 z-10`}>
        <button onClick={() => navigate('/dashboard')} className="p-2">
          <ArrowRight className={`w-6 h-6 ${darkMode ? 'text-white' : 'text-[#1a1a1a]'} ${isRTL ? '' : 'rotate-180'}`} />
        </button>
        <h2 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-xl flex-1`}>{t('chartsTitle')}</h2>
      </div>

      <div className="px-6 py-6">

        <div className="space-y-6">
          <div className={`${darkMode ? 'bg-[#1a1a1a]' : 'bg-white'} rounded-2xl p-6 shadow-sm`}>
            <div className="flex items-center justify-between mb-4">
              <h3 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-lg`}>{t('bloodSugar')}</h3>
              <TrendingUp className="w-5 h-5 text-[#27AE60]" />
            </div>
            <div className="mb-4">
              <div className="flex items-end gap-2">
                <span className="text-3xl text-[#27AE60]">94</span>
                <span className={`${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} mb-1`}>mg/dL</span>
              </div>
              <p className={`${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} text-sm`}>{t('withinNormal')}</p>
            </div>
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={glucoseData}>
                <CartesianGrid strokeDasharray="3 3" stroke={darkMode ? '#374151' : '#E5E7EB'} />
                <XAxis dataKey="date" stroke={darkMode ? '#9CA3AF' : '#6B7280'} style={{ fontSize: '12px' }} />
                <YAxis stroke={darkMode ? '#9CA3AF' : '#6B7280'} style={{ fontSize: '12px' }} />
                <Tooltip contentStyle={{ backgroundColor: darkMode ? '#1a1a1a' : '#ffffff', border: `1px solid ${darkMode ? '#374151' : '#E5E7EB'}` }} />
                <Line type="monotone" dataKey="value" stroke="#27AE60" strokeWidth={3} dot={{ fill: '#27AE60', r: 5 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className={`${darkMode ? 'bg-[#1a1a1a]' : 'bg-white'} rounded-2xl p-6 shadow-sm`}>
            <div className="flex items-center justify-between mb-4">
              <h3 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-lg`}>{t('bloodPressure')}</h3>
              <TrendingUp className="w-5 h-5 text-[#2F80ED]" />
            </div>
            <div className="mb-4">
              <div className="flex items-end gap-2">
                <span className="text-3xl text-[#2F80ED]">119/79</span>
                <span className={`${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} mb-1`}>mmHg</span>
              </div>
              <p className={`${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} text-sm`}>{t('normalPressure')}</p>
            </div>
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={bloodPressureData}>
                <CartesianGrid strokeDasharray="3 3" stroke={darkMode ? '#374151' : '#E5E7EB'} />
                <XAxis dataKey="date" stroke={darkMode ? '#9CA3AF' : '#6B7280'} style={{ fontSize: '12px' }} />
                <YAxis stroke={darkMode ? '#9CA3AF' : '#6B7280'} style={{ fontSize: '12px' }} />
                <Tooltip contentStyle={{ backgroundColor: darkMode ? '#1a1a1a' : '#ffffff', border: `1px solid ${darkMode ? '#374151' : '#E5E7EB'}` }} />
                <Line type="monotone" dataKey="systolic" stroke="#2F80ED" strokeWidth={3} dot={{ fill: '#2F80ED', r: 5 }} />
                <Line type="monotone" dataKey="diastolic" stroke="#9B51E0" strokeWidth={3} dot={{ fill: '#9B51E0', r: 5 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className={`${darkMode ? 'bg-[#1a1a1a]' : 'bg-white'} rounded-2xl p-6 shadow-sm`}>
            <div className="flex items-center justify-between mb-4">
              <h3 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-lg`}>{t('cholesterol')}</h3>
              <TrendingUp className="w-5 h-5 text-[#F2C94C]" />
            </div>
            <div className="mb-4">
              <div className="flex items-end gap-2">
                <span className="text-3xl text-[#F2C94C]">210</span>
                <span className={`${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} mb-1`}>mg/dL</span>
              </div>
              <p className={`${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} text-sm`}>{t('slightIncrease')}</p>
            </div>
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={cholesterolData}>
                <CartesianGrid strokeDasharray="3 3" stroke={darkMode ? '#374151' : '#E5E7EB'} />
                <XAxis dataKey="date" stroke={darkMode ? '#9CA3AF' : '#6B7280'} style={{ fontSize: '12px' }} />
                <YAxis stroke={darkMode ? '#9CA3AF' : '#6B7280'} style={{ fontSize: '12px' }} />
                <Tooltip contentStyle={{ backgroundColor: darkMode ? '#1a1a1a' : '#ffffff', border: `1px solid ${darkMode ? '#374151' : '#E5E7EB'}` }} />
                <Line type="monotone" dataKey="value" stroke="#F2C94C" strokeWidth={3} dot={{ fill: '#F2C94C', r: 5 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}
