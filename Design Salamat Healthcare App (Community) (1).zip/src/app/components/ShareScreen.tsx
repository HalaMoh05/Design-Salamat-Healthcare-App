import { useState } from 'react';
import { useNavigate } from 'react-router';
import { ArrowRight, Share2, Download, Link2, Mail, MessageCircle, CheckCircle2, Lock, Copy } from 'lucide-react';
import { useSettings } from '../context/SettingsContext';
import { Toast, ToastType } from './Toast';

export function ShareScreen() {
  const navigate = useNavigate();
  const { t, isRTL, darkMode } = useSettings();
  const [toast, setToast] = useState<{ message: string; type: ToastType } | null>(null);
  const [generatedLink, setGeneratedLink] = useState<string>('');

  const showToast = (message: string, type: ToastType) => {
    setToast({ message, type });
  };

  const hideToast = () => {
    setToast(null);
  };

  const simulateNetworkRequest = () => {
    return new Promise<boolean>((resolve) => {
      setTimeout(() => {
        const isOnline = Math.random() > 0.1;
        resolve(isOnline);
      }, 1500);
    });
  };

  const handleShareWithDoctor = async () => {
    showToast(t('processing'), 'loading');

    try {
      const success = await simulateNetworkRequest();

      if (!success) {
        showToast(t('noInternet'), 'error');
        return;
      }

      showToast(t('shareSuccess'), 'success');
    } catch (error) {
      showToast(t('shareFailed'), 'error');
    }
  };

  const handleCreateSecureLink = async () => {
    showToast(t('processing'), 'loading');

    try {
      const success = await simulateNetworkRequest();

      if (!success) {
        showToast(t('noInternet'), 'error');
        return;
      }

      const link = `https://salamat.jo/share/${Math.random().toString(36).substring(7)}`;
      setGeneratedLink(link);

      await navigator.clipboard.writeText(link);
      showToast(t('linkCopiedToClipboard'), 'success');
    } catch (error) {
      showToast(t('shareFailed'), 'error');
    }
  };

  const handleSendEmail = async () => {
    showToast(t('processing'), 'loading');

    try {
      const success = await simulateNetworkRequest();

      if (!success) {
        showToast(t('noInternet'), 'error');
        return;
      }

      showToast(t('emailSent'), 'success');
    } catch (error) {
      showToast(t('shareFailed'), 'error');
    }
  };

  const handleShareWhatsApp = async () => {
    showToast(t('processing'), 'loading');

    try {
      const success = await simulateNetworkRequest();

      if (!success) {
        showToast(t('noInternet'), 'error');
        return;
      }

      const message = encodeURIComponent('Check my health records on Salamat');
      const whatsappUrl = `https://wa.me/?text=${message}`;
      window.open(whatsappUrl, '_blank');
      showToast(t('shareSuccess'), 'success');
    } catch (error) {
      showToast(t('shareFailed'), 'error');
    }
  };

  const handleDownloadPDF = async () => {
    showToast(t('processing'), 'loading');

    try {
      const success = await simulateNetworkRequest();

      if (!success) {
        showToast(t('noInternet'), 'error');
        return;
      }

      const link = document.createElement('a');
      link.href = 'data:application/pdf;base64,JVBERi0xLjQKJeLjz9MKMyAwIG9iago8PC9UeXBlIC9QYWdlCi9QYXJlbnQgMSAwIFIKL01lZGlhQm94IFswIDAgNjEyIDc5Ml0KL0NvbnRlbnRzIDQgMCBSCi9SZXNvdXJjZXMgPDwvRm9udCA8PC9GMSA1IDAgUj4+Pj4KPj4KZW5kb2JqCjQgMCBvYmoKPDwvTGVuZ3RoIDQ0Pj4Kc3RyZWFtCkJUCi9GMSA0OCBUZgoxMCA3MDAgVGQKKFNhbGFtYXQgSGVhbHRoIFJlY29yZCkgVGoKRVQKZW5kc3RyZWFtCmVuZG9iago1IDAgb2JqCjw8L1R5cGUgL0ZvbnQKL1N1YnR5cGUgL1R5cGUxCi9CYXNlRm9udCAvSGVsdmV0aWNhCj4+CmVuZG9iagoxIDAgb2JqCjw8L1R5cGUgL1BhZ2VzCi9LaWRzIFszIDAgUl0KL0NvdW50IDEKPj4KZW5kb2JqCjIgMCBvYmoKPDwvVHlwZSAvQ2F0YWxvZwovUGFnZXMgMSAwIFIKPj4KZW5kb2JqCnhyZWYKMCA2CjAwMDAwMDAwMDAgNjU1MzUgZiAKMDAwMDAwMDMwOCAwMDAwMCBuIAowMDAwMDAwMzY1IDAwMDAwIG4gCjAwMDAwMDAwMDkgMDAwMDAgbiAKMDAwMDAwMDEzNyAwMDAwMCBuIAowMDAwMDAwMjI5IDAwMDAwIG4gCnRyYWlsZXIKPDwvU2l6ZSA2Ci9Sb290IDIgMCBSCj4+CnN0YXJ0eHJlZgo0MTQKJSVFT0Y=';
      link.download = 'salamat-health-record.pdf';
      link.click();

      showToast(t('downloadSuccess'), 'success');
    } catch (error) {
      showToast(t('downloadFailed'), 'error');
    }
  };

  const copyLinkToClipboard = async () => {
    if (generatedLink) {
      try {
        await navigator.clipboard.writeText(generatedLink);
        showToast(t('linkCopied'), 'success');
      } catch (error) {
        showToast(t('shareFailed'), 'error');
      }
    }
  };

  return (
    <>
      <div className={`pb-20 ${darkMode ? 'bg-[#121212]' : 'bg-[#F5F7FA]'}`} dir={isRTL ? 'rtl' : 'ltr'}>
        <div className={`${darkMode ? 'bg-[#1a1a1a] border-gray-800' : 'bg-white border-[#E5E7EB]'} px-6 py-4 flex items-center gap-3 border-b sticky top-0 z-10`}>
          <button onClick={() => navigate(-1)} className="p-2">
            <ArrowRight className={`w-6 h-6 ${darkMode ? 'text-white' : 'text-[#1a1a1a]'} ${isRTL ? '' : 'rotate-180'}`} />
          </button>
          <h2 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-xl flex-1`}>{t('shareDownload')}</h2>
        </div>

        <div className="px-6 py-6">
          <div className={`bg-gradient-to-br ${darkMode ? 'from-[#2F80ED]/20 to-[#2F80ED]/10' : 'from-[#2F80ED]/10 to-[#2F80ED]/5'} rounded-2xl p-6 mb-6`}>
            <div className="flex items-center gap-3 mb-4">
              <Lock className="w-5 h-5 text-[#2F80ED]" />
              <h3 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-lg`}>{t('secureSharing')}</h3>
            </div>
            <p className={`${darkMode ? 'text-gray-300' : 'text-[#6B7280]'} text-sm leading-relaxed`}>
              {t('secureSharingDesc')}
            </p>
          </div>

          {generatedLink && (
            <div className={`${darkMode ? 'bg-[#27AE60]/20 border-[#27AE60]' : 'bg-[#27AE60]/10 border-[#27AE60]'} border-2 rounded-2xl p-5 mb-6`}>
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <h4 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} mb-1`}>{t('secureLink')}</h4>
                  <p className={`${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} text-sm`}>{t('validFor24Hours')}</p>
                </div>
                <CheckCircle2 className="w-5 h-5 text-[#27AE60]" />
              </div>
              <div className={`${darkMode ? 'bg-gray-800' : 'bg-white'} rounded-xl p-3 flex items-center gap-2`}>
                <p className={`${darkMode ? 'text-gray-300' : 'text-[#1a1a1a]'} text-sm flex-1 break-all`}>{generatedLink}</p>
                <button
                  onClick={copyLinkToClipboard}
                  className="p-2 bg-[#2F80ED] rounded-lg hover:bg-[#1E5BB8] transition-colors"
                >
                  <Copy className="w-4 h-4 text-white" />
                </button>
              </div>
            </div>
          )}

          <h3 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-lg mb-4`}>{t('chooseShareMethod')}</h3>
          <div className="space-y-3 mb-8">
            <button
              onClick={handleShareWithDoctor}
              className={`${darkMode ? 'bg-[#1a1a1a]' : 'bg-white'} rounded-2xl p-5 shadow-sm w-full ${isRTL ? 'text-right' : 'text-left'} hover:shadow-md transition-shadow`}
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-[#2F80ED]/10 flex items-center justify-center flex-shrink-0">
                  <Share2 className="w-6 h-6 text-[#2F80ED]" />
                </div>
                <div className="flex-1">
                  <h4 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} mb-1`}>{t('shareWithDoctor')}</h4>
                  <p className={`${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} text-sm`}>{t('shareWithDoctorDesc')}</p>
                </div>
              </div>
            </button>

            <button
              onClick={handleCreateSecureLink}
              className={`${darkMode ? 'bg-[#1a1a1a]' : 'bg-white'} rounded-2xl p-5 shadow-sm w-full ${isRTL ? 'text-right' : 'text-left'} hover:shadow-md transition-shadow`}
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-[#27AE60]/10 flex items-center justify-center flex-shrink-0">
                  <Link2 className="w-6 h-6 text-[#27AE60]" />
                </div>
                <div className="flex-1">
                  <h4 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} mb-1`}>{t('createSecureLink')}</h4>
                  <p className={`${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} text-sm`}>{t('createSecureLinkDesc')}</p>
                </div>
              </div>
            </button>

            <button
              onClick={handleSendEmail}
              className={`${darkMode ? 'bg-[#1a1a1a]' : 'bg-white'} rounded-2xl p-5 shadow-sm w-full ${isRTL ? 'text-right' : 'text-left'} hover:shadow-md transition-shadow`}
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-[#F2C94C]/10 flex items-center justify-center flex-shrink-0">
                  <Mail className="w-6 h-6 text-[#F2C94C]" />
                </div>
                <div className="flex-1">
                  <h4 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} mb-1`}>{t('sendViaEmail')}</h4>
                  <p className={`${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} text-sm`}>{t('sendViaEmailDesc')}</p>
                </div>
              </div>
            </button>

            <button
              onClick={handleShareWhatsApp}
              className={`${darkMode ? 'bg-[#1a1a1a]' : 'bg-white'} rounded-2xl p-5 shadow-sm w-full ${isRTL ? 'text-right' : 'text-left'} hover:shadow-md transition-shadow`}
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-[#9B51E0]/10 flex items-center justify-center flex-shrink-0">
                  <MessageCircle className="w-6 h-6 text-[#9B51E0]" />
                </div>
                <div className="flex-1">
                  <h4 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} mb-1`}>{t('shareViaWhatsapp')}</h4>
                  <p className={`${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} text-sm`}>{t('shareViaWhatsappDesc')}</p>
                </div>
              </div>
            </button>
          </div>

          <h3 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-lg mb-4`}>{t('downloadFiles')}</h3>
          <div className="space-y-3">
            <button
              onClick={handleDownloadPDF}
              className={`${darkMode ? 'bg-[#1a1a1a]' : 'bg-white'} rounded-2xl p-5 shadow-sm w-full ${isRTL ? 'text-right' : 'text-left'} hover:shadow-md transition-shadow`}
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-[#EB5757]/10 flex items-center justify-center flex-shrink-0">
                  <Download className="w-6 h-6 text-[#EB5757]" />
                </div>
                <div className="flex-1">
                  <h4 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} mb-1`}>{t('downloadAsPDF')}</h4>
                  <p className={`${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} text-sm`}>{t('saveToDevice')}</p>
                </div>
              </div>
            </button>
          </div>

          <div className={`mt-8 ${darkMode ? 'bg-[#1a1a1a]' : 'bg-white'} rounded-2xl p-5 shadow-sm`}>
            <h4 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} mb-3`}>{t('activeShares')}</h4>
            <div className="space-y-3">
              <div className={`p-4 ${darkMode ? 'bg-gray-800' : 'bg-[#F5F7FA]'} rounded-xl`}>
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <p className={darkMode ? 'text-white' : 'text-[#1a1a1a]'}>{t('drAhmadHamoud')}</p>
                    <p className={`${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} text-sm`}>
                      {t('expiresIn')} 18 {t('hours')}
                    </p>
                  </div>
                  <CheckCircle2 className="w-5 h-5 text-[#27AE60]" />
                </div>
                <div className="flex items-center gap-2 text-[#2F80ED] text-sm">
                  <Lock className="w-4 h-4" />
                  <span>{t('passwordProtected')}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {toast && <Toast message={toast.message} type={toast.type} onClose={hideToast} />}
    </>
  );
}
