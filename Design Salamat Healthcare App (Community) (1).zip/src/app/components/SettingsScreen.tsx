import { useState } from 'react';
import { useNavigate } from 'react-router';
import { ArrowRight, Moon, Type, Globe, Bell, Lock, ChevronLeft, CheckCircle2, Database } from 'lucide-react';
import { useSettings } from '../context/SettingsContext';
import { PrivacyPolicyModal } from './PrivacyPolicyModal';

export function SettingsScreen() {
  const navigate = useNavigate();
  const {
    darkMode,
    setDarkMode,
    fontSize,
    setFontSize,
    language,
    setLanguage,
    notifications,
    setNotifications,
    newResults,
    setNewResults,
    reminders,
    setReminders,
    t,
    isRTL,
  } = useSettings();
  const [showPrivacyModal, setShowPrivacyModal] = useState(false);

  return (
    <>
      <div className={`pb-20 ${darkMode ? 'bg-[#121212]' : 'bg-[#F5F7FA]'}`} dir={isRTL ? 'rtl' : 'ltr'}>
        <div className={`${darkMode ? 'bg-[#1a1a1a] border-gray-800' : 'bg-white border-[#E5E7EB]'} px-6 py-4 flex items-center gap-3 border-b sticky top-0 z-10`}>
          <button onClick={() => navigate('/dashboard')} className="p-2">
            <ArrowRight className={`w-6 h-6 ${darkMode ? 'text-white' : 'text-[#1a1a1a]'} ${isRTL ? '' : 'rotate-180'}`} />
          </button>
          <h2 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-xl flex-1`}>{t('settings')}</h2>
        </div>

      <div className="px-6 py-6 space-y-6">
        <div className={`${darkMode ? 'bg-[#1a1a1a]' : 'bg-white'} rounded-2xl p-6 shadow-sm`}>
          <div className="flex items-center gap-2 mb-4">
            <Moon className="w-5 h-5 text-[#2F80ED]" />
            <h3 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-lg`}>{t('appearance')}</h3>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Moon className={`w-5 h-5 ${darkMode ? 'text-gray-400' : 'text-[#6B7280]'}`} />
                <span className={darkMode ? 'text-white' : 'text-[#1a1a1a]'}>{t('darkMode')}</span>
              </div>
              <button
                onClick={() => setDarkMode(!darkMode)}
                className={`relative w-12 h-6 rounded-full transition-colors ${
                  darkMode ? 'bg-[#2F80ED]' : 'bg-[#D1D5DB]'
                }`}
              >
                <div
                  className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform ${
                    darkMode ? (isRTL ? '-translate-x-7' : 'translate-x-7') : (isRTL ? '-translate-x-1' : 'translate-x-1')
                  }`}
                />
              </button>
            </div>

            <div className={`pt-4 border-t ${darkMode ? 'border-gray-800' : 'border-[#E5E7EB]'}`}>
              <div className="flex items-center gap-3 mb-3">
                <Type className={`w-5 h-5 ${darkMode ? 'text-gray-400' : 'text-[#6B7280]'}`} />
                <span className={darkMode ? 'text-white' : 'text-[#1a1a1a]'}>{t('fontSize')}</span>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => setFontSize('small')}
                  className={`flex-1 py-2 px-4 rounded-lg border-2 transition-colors ${
                    fontSize === 'small'
                      ? 'border-[#2F80ED] bg-[#2F80ED]/10 text-[#2F80ED]'
                      : `${darkMode ? 'border-gray-700 text-gray-400' : 'border-[#E5E7EB] text-[#6B7280]'}`
                  }`}
                >
                  {t('small')}
                </button>
                <button
                  onClick={() => setFontSize('medium')}
                  className={`flex-1 py-2 px-4 rounded-lg border-2 transition-colors ${
                    fontSize === 'medium'
                      ? 'border-[#2F80ED] bg-[#2F80ED]/10 text-[#2F80ED]'
                      : `${darkMode ? 'border-gray-700 text-gray-400' : 'border-[#E5E7EB] text-[#6B7280]'}`
                  }`}
                >
                  {t('medium')}
                </button>
                <button
                  onClick={() => setFontSize('large')}
                  className={`flex-1 py-2 px-4 rounded-lg border-2 transition-colors ${
                    fontSize === 'large'
                      ? 'border-[#2F80ED] bg-[#2F80ED]/10 text-[#2F80ED]'
                      : `${darkMode ? 'border-gray-700 text-gray-400' : 'border-[#E5E7EB] text-[#6B7280]'}`
                  }`}
                >
                  {t('large')}
                </button>
              </div>
            </div>
          </div>
        </div>

        <div className={`${darkMode ? 'bg-[#1a1a1a]' : 'bg-white'} rounded-2xl p-6 shadow-sm`}>
          <div className="flex items-center gap-2 mb-4">
            <Globe className="w-5 h-5 text-[#2F80ED]" />
            <h3 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-lg`}>{t('language')}</h3>
          </div>

          <div className="space-y-2">
            <button
              onClick={() => setLanguage('ar')}
              className={`w-full flex items-center justify-between p-4 rounded-xl border-2 transition-colors ${
                language === 'ar'
                  ? 'border-[#2F80ED] bg-[#2F80ED]/10'
                  : `${darkMode ? 'border-gray-700' : 'border-[#E5E7EB]'}`
              }`}
            >
              <span className={darkMode ? 'text-white' : 'text-[#1a1a1a]'}>{t('arabic')}</span>
              {language === 'ar' && <CheckCircle2 className="w-5 h-5 text-[#2F80ED]" />}
            </button>
            <button
              onClick={() => setLanguage('en')}
              className={`w-full flex items-center justify-between p-4 rounded-xl border-2 transition-colors ${
                language === 'en'
                  ? 'border-[#2F80ED] bg-[#2F80ED]/10'
                  : `${darkMode ? 'border-gray-700' : 'border-[#E5E7EB]'}`
              }`}
            >
              <span className={darkMode ? 'text-white' : 'text-[#1a1a1a]'}>{t('english')}</span>
              {language === 'en' && <CheckCircle2 className="w-5 h-5 text-[#2F80ED]" />}
            </button>
          </div>
        </div>


        <div className={`${darkMode ? 'bg-[#1a1a1a]' : 'bg-white'} rounded-2xl p-6 shadow-sm`}>
          <div className="flex items-center gap-2 mb-4">
            <Bell className="w-5 h-5 text-[#2F80ED]" />
            <h3 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-lg`}>{t('notificationsSettings')}</h3>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className={darkMode ? 'text-white' : 'text-[#1a1a1a]'}>{t('enableNotifications')}</span>
              <button
                onClick={() => setNotifications(!notifications)}
                className={`relative w-12 h-6 rounded-full transition-colors ${
                  notifications ? 'bg-[#2F80ED]' : 'bg-[#D1D5DB]'
                }`}
              >
                <div
                  className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform ${
                    notifications ? (isRTL ? '-translate-x-7' : 'translate-x-7') : (isRTL ? '-translate-x-1' : 'translate-x-1')
                  }`}
                />
              </button>
            </div>

            {notifications && (
              <>
                <div className={`flex items-center justify-between pt-4 border-t ${darkMode ? 'border-gray-800' : 'border-[#E5E7EB]'}`}>
                  <span className={darkMode ? 'text-white' : 'text-[#1a1a1a]'}>{t('newResults')}</span>
                  <button
                    onClick={() => setNewResults(!newResults)}
                    className={`relative w-12 h-6 rounded-full transition-colors ${
                      newResults ? 'bg-[#2F80ED]' : 'bg-[#D1D5DB]'
                    }`}
                  >
                    <div
                      className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform ${
                        newResults ? (isRTL ? '-translate-x-7' : 'translate-x-7') : (isRTL ? '-translate-x-1' : 'translate-x-1')
                      }`}
                    />
                  </button>
                </div>

                <div className={`flex items-center justify-between pt-4 border-t ${darkMode ? 'border-gray-800' : 'border-[#E5E7EB]'}`}>
                  <span className={darkMode ? 'text-white' : 'text-[#1a1a1a]'}>{t('reminders')}</span>
                  <button
                    onClick={() => setReminders(!reminders)}
                    className={`relative w-12 h-6 rounded-full transition-colors ${
                      reminders ? 'bg-[#2F80ED]' : 'bg-[#D1D5DB]'
                    }`}
                  >
                    <div
                      className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform ${
                        reminders ? (isRTL ? '-translate-x-7' : 'translate-x-7') : (isRTL ? '-translate-x-1' : 'translate-x-1')
                      }`}
                    />
                  </button>
                </div>
              </>
            )}
          </div>
        </div>

        <div className={`${darkMode ? 'bg-[#1a1a1a]' : 'bg-white'} rounded-2xl p-6 shadow-sm`}>
          <div className="flex items-center gap-2 mb-4">
            <Database className="w-5 h-5 text-[#2F80ED]" />
            <h3 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-lg`}>{t('dataUsage')}</h3>
          </div>
          <button
            onClick={() => navigate('/data-usage')}
            className={`w-full flex items-center justify-between p-4 ${darkMode ? 'bg-gray-800' : 'bg-[#F5F7FA]'} rounded-xl hover:bg-[#E5E7EB] transition-colors`}
          >
            <span className={darkMode ? 'text-white' : 'text-[#1a1a1a]'}>{t('viewExportData')}</span>
            <ChevronLeft className={`w-5 h-5 ${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} ${isRTL ? '' : 'rotate-180'}`} />
          </button>
        </div>

        <div className={`${darkMode ? 'bg-[#1a1a1a]' : 'bg-white'} rounded-2xl p-6 shadow-sm`}>
          <div className="flex items-center gap-2 mb-4">
            <Lock className="w-5 h-5 text-[#2F80ED]" />
            <h3 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-lg`}>{t('privacySecurity')}</h3>
          </div>

          <div className={`p-4 bg-gradient-to-br ${darkMode ? 'from-[#27AE60]/20 to-[#27AE60]/10' : 'from-[#27AE60]/10 to-[#27AE60]/5'} rounded-xl mb-4`}>
            <div className="flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-[#27AE60] mt-0.5 flex-shrink-0" />
              <div>
                <p className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} mb-1`}>{t('dataProtected')}</p>
                <p className={`${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} text-sm`}>{t('dataSecure')}</p>
              </div>
            </div>
          </div>

          <button
            onClick={() => setShowPrivacyModal(true)}
            className="w-full bg-[#2F80ED] text-white py-3 px-4 rounded-xl hover:bg-[#2F80ED]/90 transition-colors"
          >
            {t('morePrivacy')}
          </button>
        </div>
        </div>
      </div>

      <PrivacyPolicyModal isOpen={showPrivacyModal} onClose={() => setShowPrivacyModal(false)} />
    </>
  );
}
