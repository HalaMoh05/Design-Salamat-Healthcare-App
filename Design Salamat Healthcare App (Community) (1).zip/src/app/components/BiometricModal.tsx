import { Fingerprint } from 'lucide-react';
import { useSettings } from '../context/SettingsContext';

interface BiometricModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export function BiometricModal({ isOpen, onClose, onSuccess }: BiometricModalProps) {
  const { t, isRTL, darkMode } = useSettings();

  if (!isOpen) return null;

  const handleBiometric = () => {
    setTimeout(() => {
      onSuccess();
    }, 1500);
  };

  return (
    <div
      className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-6"
      onClick={onClose}
    >
      <div
        className={`${darkMode ? 'bg-[#1a1a1a]' : 'bg-white'} rounded-2xl max-w-sm w-full p-8`}
        onClick={(e) => e.stopPropagation()}
        dir={isRTL ? 'rtl' : 'ltr'}
      >
        <div className="flex flex-col items-center">
          <div className="w-24 h-24 rounded-full bg-[#2F80ED]/10 flex items-center justify-center mb-6 animate-pulse">
            <Fingerprint className="w-12 h-12 text-[#2F80ED]" />
          </div>
          <h3 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-xl mb-2 text-center`}>
            {t('biometricTitle')}
          </h3>
          <p className={`${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} text-center mb-6`}>
            {t('biometricMessage')}
          </p>
          <button
            onClick={handleBiometric}
            className="w-full bg-[#2F80ED] text-white py-3 px-4 rounded-xl hover:bg-[#2F80ED]/90 transition-colors"
          >
            {t('confirm')}
          </button>
          <button
            onClick={onClose}
            className={`w-full mt-3 ${darkMode ? 'bg-gray-800 text-gray-300' : 'bg-[#F5F7FA] text-[#6B7280]'} py-3 px-4 rounded-xl hover:bg-[#E5E7EB] transition-colors`}
          >
            {t('cancel')}
          </button>
        </div>
      </div>
    </div>
  );
}
