import { useNavigate } from 'react-router';
import { ArrowRight, User, CheckCircle2, Hospital, FlaskConical } from 'lucide-react';
import { useSettings } from '../context/SettingsContext';

export function ProfileScreen() {
  const navigate = useNavigate();
  const { t, isRTL, darkMode } = useSettings();

  const connectedEntities = [
    {
      id: 1,
      name: t('bashirHospital'),
      type: 'hospital',
      verified: true
    },
    {
      id: 2,
      name: t('hamzaHospital'),
      type: 'hospital',
      verified: true
    },
    {
      id: 3,
      name: t('biochemistryLabs'),
      type: 'lab',
      verified: true
    },
  ];

  return (
    <div className={`pb-20 ${darkMode ? 'bg-[#121212]' : 'bg-[#F5F7FA]'}`} dir={isRTL ? 'rtl' : 'ltr'}>
      <div className={`${darkMode ? 'bg-[#1a1a1a] border-gray-800' : 'bg-white border-[#E5E7EB]'} px-6 py-4 flex items-center gap-3 border-b sticky top-0 z-10`}>
        <button onClick={() => navigate('/dashboard')} className="p-2">
          <ArrowRight className={`w-6 h-6 ${darkMode ? 'text-white' : 'text-[#1a1a1a]'} ${isRTL ? '' : 'rotate-180'}`} />
        </button>
        <h2 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-xl flex-1`}>{t('profile')}</h2>
      </div>

      <div className="px-6 py-6">
        <div className="bg-gradient-to-br from-[#2F80ED] to-[#1E5BB8] rounded-2xl p-6 mb-6 text-white">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-20 h-20 rounded-full bg-white/20 flex items-center justify-center">
              <User className="w-10 h-10 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="text-2xl mb-2">
                {isRTL ? 'محمد أحمد الخطيب' : 'Mohammad Ahmad Al-Khatib'}
              </h3>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4" />
                <span className="text-sm">{t('verifiedViaSanad')}</span>
              </div>
            </div>
          </div>
        </div>

        <div className={`${darkMode ? 'bg-[#1a1a1a]' : 'bg-white'} rounded-2xl p-6 shadow-sm mb-6`}>
          <h3 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-lg mb-4`}>{t('personalInfo')}</h3>
          <div className="space-y-4">
            <div className={`flex items-center justify-between pb-3 border-b ${darkMode ? 'border-gray-800' : 'border-[#E5E7EB]'}`}>
              <span className={darkMode ? 'text-gray-400' : 'text-[#6B7280]'}>{t('nationalIdNumber')}</span>
              <span className={darkMode ? 'text-white' : 'text-[#1a1a1a]'}>9851234567</span>
            </div>
            <div className={`flex items-center justify-between pb-3 border-b ${darkMode ? 'border-gray-800' : 'border-[#E5E7EB]'}`}>
              <span className={darkMode ? 'text-gray-400' : 'text-[#6B7280]'}>{t('dateOfBirth')}</span>
              <span className={darkMode ? 'text-white' : 'text-[#1a1a1a]'}>
                {isRTL ? '15 يناير 1985' : 'January 15, 1985'}
              </span>
            </div>
            <div className={`flex items-center justify-between pb-3 border-b ${darkMode ? 'border-gray-800' : 'border-[#E5E7EB]'}`}>
              <span className={darkMode ? 'text-gray-400' : 'text-[#6B7280]'}>{t('bloodType')}</span>
              <span className={darkMode ? 'text-white' : 'text-[#1a1a1a]'}>O+</span>
            </div>
            <div className="flex items-center justify-between">
              <span className={darkMode ? 'text-gray-400' : 'text-[#6B7280]'}>{t('phoneNumber')}</span>
              <span className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'}`} dir="ltr">+962 79 123 4567</span>
            </div>
          </div>
        </div>

        <div className={`${darkMode ? 'bg-[#1a1a1a]' : 'bg-white'} rounded-2xl p-6 shadow-sm mb-6`}>
          <div className="flex items-center gap-2 mb-4">
            <CheckCircle2 className="w-5 h-5 text-[#27AE60]" />
            <h3 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-lg`}>{t('identityVerification')}</h3>
          </div>
          <div className={`p-4 ${darkMode ? 'bg-[#27AE60]/20' : 'bg-[#27AE60]/10'} rounded-xl`}>
            <div className="flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-[#27AE60] mt-0.5" />
              <div>
                <p className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} mb-1`}>{t('verifiedBySanad')}</p>
                <p className={`${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} text-sm`}>{t('verifiedBySanadDesc')}</p>
              </div>
            </div>
          </div>
        </div>

        <div className={`${darkMode ? 'bg-[#1a1a1a]' : 'bg-white'} rounded-2xl p-6 shadow-sm`}>
          <h3 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-lg mb-4`}>{t('connectedEntities')}</h3>
          <div className="space-y-3">
            {connectedEntities.map((entity) => (
              <div key={entity.id} className={`flex items-center gap-3 p-4 ${darkMode ? 'bg-gray-800' : 'bg-[#F5F7FA]'} rounded-xl`}>
                <div className={`w-12 h-12 rounded-full ${darkMode ? 'bg-[#2a2a2a]' : 'bg-white'} flex items-center justify-center flex-shrink-0`}>
                  {entity.type === 'hospital' ? (
                    <Hospital className="w-6 h-6 text-[#2F80ED]" />
                  ) : (
                    <FlaskConical className="w-6 h-6 text-[#2F80ED]" />
                  )}
                </div>
                <div className="flex-1">
                  <p className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} mb-1`}>{entity.name}</p>
                  {entity.verified && (
                    <div className="flex items-center gap-1 text-[#27AE60] text-sm">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>{t('verified')}</span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
