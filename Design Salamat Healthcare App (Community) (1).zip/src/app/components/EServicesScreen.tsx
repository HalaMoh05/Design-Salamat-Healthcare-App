import { useNavigate } from 'react-router';
import { ArrowRight, FileText, Share2, Download, Clock, CheckCircle2, AlertCircle } from 'lucide-react';

export function EServicesScreen() {
  const navigate = useNavigate();

  const services = [
    {
      id: 1,
      title: 'طلب تقرير طبي',
      description: 'احصل على تقرير طبي شامل لجميع سجلاتك',
      icon: FileText,
      available: true
    },
    {
      id: 2,
      title: 'مشاركة النتائج',
      description: 'شارك نتائجك الطبية مع طبيبك',
      icon: Share2,
      available: true
    },
    {
      id: 3,
      title: 'تحميل السجلات',
      description: 'حمل نسخة من سجلاتك الطبية',
      icon: Download,
      available: true
    },
  ];

  const requests = [
    {
      id: 1,
      title: 'تقرير طبي شامل',
      date: '20 أبريل 2026',
      status: 'approved',
      statusText: 'موافق عليه'
    },
    {
      id: 2,
      title: 'مشاركة نتائج التحاليل',
      date: '18 أبريل 2026',
      status: 'completed',
      statusText: 'مكتمل'
    },
    {
      id: 3,
      title: 'طلب تقرير للتأمين',
      date: '15 أبريل 2026',
      status: 'processing',
      statusText: 'قيد المعالجة'
    },
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle2 className="w-5 h-5 text-[#27AE60]" />;
      case 'approved':
        return <CheckCircle2 className="w-5 h-5 text-[#2F80ED]" />;
      case 'processing':
        return <Clock className="w-5 h-5 text-[#F2C94C]" />;
      default:
        return <AlertCircle className="w-5 h-5 text-[#6B7280]" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'text-[#27AE60] bg-[#27AE60]/10';
      case 'approved':
        return 'text-[#2F80ED] bg-[#2F80ED]/10';
      case 'processing':
        return 'text-[#F2C94C] bg-[#F2C94C]/10';
      default:
        return 'text-[#6B7280] bg-[#F5F7FA]';
    }
  };

  return (
    <div className="pb-20">
      <div className="bg-white px-6 py-4 flex items-center gap-3 border-b border-[#E5E7EB] sticky top-0 z-10">
        <button onClick={() => navigate('/dashboard')} className="p-2">
          <ArrowRight className="w-6 h-6 text-[#1a1a1a]" />
        </button>
        <h2 className="text-[#1a1a1a] text-xl flex-1">الخدمات الإلكترونية</h2>
      </div>

      <div className="px-6 py-6">
        <h3 className="text-[#1a1a1a] text-lg mb-4">الخدمات المتاحة</h3>
        <div className="space-y-3 mb-8">
          {services.map((service) => (
            <button
              key={service.id}
              onClick={() => navigate('/share')}
              className="bg-white rounded-2xl p-5 shadow-sm w-full text-right hover:shadow-md transition-shadow"
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-[#2F80ED]/10 flex items-center justify-center flex-shrink-0">
                  <service.icon className="w-6 h-6 text-[#2F80ED]" />
                </div>
                <div className="flex-1">
                  <h4 className="text-[#1a1a1a] mb-1">{service.title}</h4>
                  <p className="text-[#6B7280] text-sm">{service.description}</p>
                </div>
              </div>
            </button>
          ))}
        </div>

        <h3 className="text-[#1a1a1a] text-lg mb-4">طلباتك السابقة</h3>
        <div className="space-y-3">
          {requests.map((request) => (
            <div
              key={request.id}
              className="bg-white rounded-2xl p-5 shadow-sm"
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <h4 className="text-[#1a1a1a] mb-2">{request.title}</h4>
                  <p className="text-[#6B7280] text-sm">{request.date}</p>
                </div>
                {getStatusIcon(request.status)}
              </div>
              <div className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-sm ${getStatusColor(request.status)}`}>
                <span>{request.statusText}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
