import { useState } from 'react';
import { useNavigate, useParams } from 'react-router';
import { ArrowRight, FileText, ZoomIn, ZoomOut, Eye, EyeOff, TrendingUp, CheckCircle2, AlertTriangle, Share2 } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { useSettings } from '../context/SettingsContext';

export function AnalysisDetailsScreen() {
  const navigate = useNavigate();
  const { id } = useParams();
  const { t, isRTL, darkMode } = useSettings();
  const [showPdf, setShowPdf] = useState(false);

  const glucoseData = [
    { dateAr: 'يناير', dateEn: 'January', value: 95 },
    { dateAr: 'فبراير', dateEn: 'February', value: 92 },
    { dateAr: 'مارس', dateEn: 'March', value: 98 },
    { dateAr: 'أبريل', dateEn: 'April', value: 94 },
  ].map(item => ({ ...item, date: isRTL ? item.dateAr : item.dateEn }));

  const cholesterolData = [
    { dateAr: 'يناير', dateEn: 'January', value: 180 },
    { dateAr: 'فبراير', dateEn: 'February', value: 185 },
    { dateAr: 'مارس', dateEn: 'March', value: 195 },
    { dateAr: 'أبريل', dateEn: 'April', value: 210 },
  ].map(item => ({ ...item, date: isRTL ? item.dateAr : item.dateEn }));

  const testResults = [
    { name: t('fastingGlucose'), value: '94', normalRange: '70-100', unit: 'mg/dL', status: 'normal' },
    { name: t('hba1c'), value: '5.4', normalRange: '4.0-5.6', unit: '%', status: 'normal' },
    { name: t('totalCholesterol'), value: '210', normalRange: '< 200', unit: 'mg/dL', status: 'warning' },
    { name: t('hdlCholesterol'), value: '52', normalRange: '> 40', unit: 'mg/dL', status: 'normal' },
    { name: t('ldlCholesterol'), value: '135', normalRange: '< 100', unit: 'mg/dL', status: 'warning' },
    { name: t('triglycerides'), value: '115', normalRange: '< 150', unit: 'mg/dL', status: 'normal' },
  ];


  return (
    <div className={`pb-20 ${darkMode ? 'bg-[#121212]' : 'bg-[#F5F7FA]'}`} dir={isRTL ? 'rtl' : 'ltr'}>
      <div className={`${darkMode ? 'bg-[#1a1a1a] border-gray-800' : 'bg-white border-[#E5E7EB]'} px-6 py-4 flex items-center gap-3 border-b sticky top-0 z-10`}>
        <button onClick={() => navigate('/lab-results')} className="p-2">
          <ArrowRight className={`w-6 h-6 ${darkMode ? 'text-white' : 'text-[#1a1a1a]'} ${isRTL ? '' : 'rotate-180'}`} />
        </button>
        <h2 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-xl flex-1`}>{t('analysisDetails')}</h2>
        <button onClick={() => navigate('/share')} className="p-2">
          <Share2 className="w-5 h-5 text-[#2F80ED]" />
        </button>
      </div>

      <div className="px-6 py-6 space-y-6">
        <div className={`${darkMode ? 'bg-[#1a1a1a]' : 'bg-white'} rounded-2xl p-6 shadow-sm`}>
          <div className="flex items-center justify-between mb-4">
            <h3 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-lg`}>{t('pdfReport')}</h3>
            <div className="flex items-center gap-2">
              <button className={`p-2 ${darkMode ? 'hover:bg-gray-800' : 'hover:bg-[#F5F7FA]'} rounded-lg`}>
                <ZoomIn className={`w-5 h-5 ${darkMode ? 'text-gray-400' : 'text-[#6B7280]'}`} />
              </button>
              <button className={`p-2 ${darkMode ? 'hover:bg-gray-800' : 'hover:bg-[#F5F7FA]'} rounded-lg`}>
                <ZoomOut className={`w-5 h-5 ${darkMode ? 'text-gray-400' : 'text-[#6B7280]'}`} />
              </button>
              <button
                onClick={() => setShowPdf(!showPdf)}
                className={`p-2 ${darkMode ? 'hover:bg-gray-800' : 'hover:bg-[#F5F7FA]'} rounded-lg`}
              >
                {showPdf ?
                  <EyeOff className={`w-5 h-5 ${darkMode ? 'text-gray-400' : 'text-[#6B7280]'}`} /> :
                  <Eye className={`w-5 h-5 ${darkMode ? 'text-gray-400' : 'text-[#6B7280]'}`} />
                }
              </button>
            </div>
          </div>
          {showPdf && (
            <div className={`${darkMode ? 'bg-gray-800' : 'bg-[#F5F7FA]'} rounded-xl p-8 text-center`}>
              <FileText className={`w-16 h-16 ${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} mx-auto mb-4`} />
              <p className={darkMode ? 'text-gray-400' : 'text-[#6B7280]'}>
                {isRTL ? 'معاينة ملف PDF' : 'PDF Preview'}
              </p>
            </div>
          )}
        </div>

        <div>
          <h3 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-lg mb-4`}>{t('quickSummary')}</h3>
          <div className="grid grid-cols-2 gap-3">
            <div className={`${darkMode ? 'bg-[#27AE60]/20' : 'bg-[#27AE60]/10'} rounded-2xl p-4 border-2 border-[#27AE60]/20`}>
              <div className="flex items-center gap-2 mb-2">
                <CheckCircle2 className="w-5 h-5 text-[#27AE60]" />
                <span className="text-[#27AE60] text-sm">{t('normal')}</span>
              </div>
              <p className={darkMode ? 'text-white' : 'text-[#1a1a1a]'}>{t('glucose')}</p>
              <p className="text-2xl text-[#27AE60] mt-1">94</p>
            </div>
            <div className={`${darkMode ? 'bg-[#F2C94C]/20' : 'bg-[#F2C94C]/10'} rounded-2xl p-4 border-2 border-[#F2C94C]/20`}>
              <div className="flex items-center gap-2 mb-2">
                <AlertTriangle className="w-5 h-5 text-[#F2C94C]" />
                <span className="text-[#F2C94C] text-sm">{t('warning')}</span>
              </div>
              <p className={darkMode ? 'text-white' : 'text-[#1a1a1a]'}>{t('cholesterol')}</p>
              <p className="text-2xl text-[#F2C94C] mt-1">210</p>
            </div>
          </div>
        </div>

        <div className={`${darkMode ? 'bg-[#1a1a1a]' : 'bg-white'} rounded-2xl p-6 shadow-sm`}>
          <div className="flex items-center justify-between mb-4">
            <h3 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-lg`}>{t('graph')}</h3>
            <TrendingUp className="w-5 h-5 text-[#2F80ED]" />
          </div>
          <div className="mb-6">
            <p className={`${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} text-sm mb-2`}>{t('bloodSugar')}</p>
            <ResponsiveContainer width="100%" height={150}>
              <LineChart data={glucoseData}>
                <CartesianGrid strokeDasharray="3 3" stroke={darkMode ? '#374151' : '#E5E7EB'} />
                <XAxis
                  dataKey="date"
                  stroke={darkMode ? '#9CA3AF' : '#6B7280'}
                  style={{ fontSize: '12px' }}
                />
                <YAxis
                  stroke={darkMode ? '#9CA3AF' : '#6B7280'}
                  style={{ fontSize: '12px' }}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: darkMode ? '#1a1a1a' : '#ffffff',
                    border: `1px solid ${darkMode ? '#374151' : '#E5E7EB'}`,
                    borderRadius: '8px',
                    color: darkMode ? '#ffffff' : '#1a1a1a'
                  }}
                  labelStyle={{ color: darkMode ? '#9CA3AF' : '#6B7280' }}
                />
                <Line type="monotone" dataKey="value" stroke="#27AE60" strokeWidth={2} dot={{ fill: '#27AE60' }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <div>
            <p className={`${darkMode ? 'text-gray-400' : 'text-[#6B7280]'} text-sm mb-2`}>{t('cholesterol')}</p>
            <ResponsiveContainer width="100%" height={150}>
              <LineChart data={cholesterolData}>
                <CartesianGrid strokeDasharray="3 3" stroke={darkMode ? '#374151' : '#E5E7EB'} />
                <XAxis
                  dataKey="date"
                  stroke={darkMode ? '#9CA3AF' : '#6B7280'}
                  style={{ fontSize: '12px' }}
                />
                <YAxis
                  stroke={darkMode ? '#9CA3AF' : '#6B7280'}
                  style={{ fontSize: '12px' }}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: darkMode ? '#1a1a1a' : '#ffffff',
                    border: `1px solid ${darkMode ? '#374151' : '#E5E7EB'}`,
                    borderRadius: '8px',
                    color: darkMode ? '#ffffff' : '#1a1a1a'
                  }}
                  labelStyle={{ color: darkMode ? '#9CA3AF' : '#6B7280' }}
                />
                <Line type="monotone" dataKey="value" stroke="#F2C94C" strokeWidth={2} dot={{ fill: '#F2C94C' }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className={`bg-gradient-to-br ${darkMode ? 'from-[#2F80ED]/20 to-[#2F80ED]/10' : 'from-[#2F80ED]/10 to-[#2F80ED]/5'} rounded-2xl p-6`}>
          <h3 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-lg mb-4`}>{t('whatDoesItMean')}</h3>
          <div className="space-y-3">
            <div className="flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-[#27AE60] mt-0.5 flex-shrink-0" />
              <p className={darkMode ? 'text-gray-200' : 'text-[#1a1a1a]'}>{t('glucoseNormal')}</p>
            </div>
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-[#F2C94C] mt-0.5 flex-shrink-0" />
              <p className={darkMode ? 'text-gray-200' : 'text-[#1a1a1a]'}>{t('cholesterolSlightlyHigh')}</p>
            </div>
            <div className="flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-[#27AE60] mt-0.5 flex-shrink-0" />
              <p className={darkMode ? 'text-gray-200' : 'text-[#1a1a1a]'}>{t('hdlNormal')}</p>
            </div>
          </div>
        </div>

        <div className={`${darkMode ? 'bg-[#1a1a1a]' : 'bg-white'} rounded-2xl p-6 shadow-sm`}>
          <h3 className={`${darkMode ? 'text-white' : 'text-[#1a1a1a]'} text-lg mb-4`}>{t('detailedAnalysis')}</h3>
          <div className="space-y-3">
            {testResults.map((test, index) => (
              <div key={index} className={`border-b ${darkMode ? 'border-gray-800' : 'border-[#E5E7EB]'} last:border-0 pb-3 last:pb-0`}>
                <div className="flex items-center justify-between mb-2">
                  <p className={darkMode ? 'text-white' : 'text-[#1a1a1a]'}>{test.name}</p>
                  {test.status === 'normal' ? (
                    <CheckCircle2 className="w-5 h-5 text-[#27AE60]" />
                  ) : (
                    <AlertTriangle className="w-5 h-5 text-[#F2C94C]" />
                  )}
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className={darkMode ? 'text-gray-400' : 'text-[#6B7280]'}>{t('value')}: <span className={darkMode ? 'text-white' : 'text-[#1a1a1a]'}>{test.value} {test.unit}</span></span>
                  <span className={darkMode ? 'text-gray-400' : 'text-[#6B7280]'}>{t('normalRange')}: {test.normalRange}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
}
