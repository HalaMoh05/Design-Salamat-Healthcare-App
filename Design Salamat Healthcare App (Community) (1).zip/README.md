
  # Design Salamat Healthcare App (Community)

  This is a code bundle for Design Salamat Healthcare App (Community). The original project is available at https://www.figma.com/design/DaWYMuO7XNosrFjpgAzdL3/Design-Salamat-Healthcare-App--Community-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  